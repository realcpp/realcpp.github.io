#!/bin/bash
PWD="$(pwd)"
BUILD=$PWD/build/win64_MinSizeRel_shared
mkdir -p $BUILD
cd $BUILD
cmake -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=MinSizeRel ../../
mingw32-make -j$1