#!/bin/bash
PWD="$(pwd)"

echo "PWD = $PWD"
echo "Argv[0] = $0"
echo "Argv[1] = $1"
echo "Argv[2] = $2"

BUILD=$PWD/build/win64_Debug_static
mkdir -p $BUILD
cd $BUILD
cmake -G "MinGW Makefiles" \
   -DBUILD_STATIC=1 \
   -DCMAKE_BUILD_TYPE=Debug \
   -DCMAKE_MODULE_PATH=C:/SDK/Qt/5.12.3/mingw73_64/lib/cmake \
   -DCMAKE_PREFIX_PATH=C:/SDK/Qt/5.12.3/mingw73_64/lib/cmake \
   ../../
mingw32-make -j$1
# make install
# -DCMAKE_MODULE_PATH=C:/SDK/Qt/5.12.3/mingw73_64/lib/cmake \