#pragma once
#include "App.hpp"

void GCodeParserApp_onWMCreate( HWND hwnd ); // fn needed by eventHandler.

bool GCodeParserApp_createApp();
