#include "App.hpp"

GCodeParserApp g_app;
