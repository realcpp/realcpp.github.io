#include "CNC_Word.hpp"

namespace de {
namespace cnc {

} // end namespace cnc
} // end namespace de
