#pragma once
#include "App.hpp"

LRESULT CALLBACK 
GCodeParserApp_eventHandler(  HWND hwnd, UINT message, 
                              WPARAM wParam, LPARAM lParam );
