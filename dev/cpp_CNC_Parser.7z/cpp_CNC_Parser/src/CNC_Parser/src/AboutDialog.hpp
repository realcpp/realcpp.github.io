#pragma once
#include <de_win32api.hpp>

void doModalAboutDialog( HWND parent );
