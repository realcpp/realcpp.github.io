#!/bin/bash
PWD="$(pwd)"

echo "PWD = $PWD"
echo "Argv[0] = $0"
echo "Argv[1] = $1"
echo "Argv[2] = $2"

BUILD=$PWD/build/win64_Debug_shared
mkdir -p $BUILD
cd $BUILD
cmake \
   -G "MinGW Makefiles" \
   -DCMAKE_BUILD_TYPE=Debug \
   -DCMAKE_PREFIX_PATH=C:/SDK/Qt/5.12.3/mingw73_64/lib/cmake \
   -DCMAKE_MODULE_PATH=C:/SDK/Qt/5.12.3/mingw73_64/lib/cmake \
../../
mingw32-make -j$1
