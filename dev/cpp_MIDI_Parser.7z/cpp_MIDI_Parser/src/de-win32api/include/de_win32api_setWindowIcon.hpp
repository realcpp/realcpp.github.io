#pragma once
#include <cstdint>

void setWindowIcon( uint64_t winHandle, int iRessourceID );
