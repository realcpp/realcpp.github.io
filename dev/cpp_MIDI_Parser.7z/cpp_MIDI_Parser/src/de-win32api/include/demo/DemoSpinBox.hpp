#pragma once
#include <de_win32api.hpp>

HWND
createDemoSpinBox( int x, int y, int w, int h, HWND parent, int id );

