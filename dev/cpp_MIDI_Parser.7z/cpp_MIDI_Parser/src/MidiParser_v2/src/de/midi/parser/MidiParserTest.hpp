#pragma once
#include "MidiParser.hpp"

namespace de {

// =======================================================================
struct MidiParserConsolePrinterListener : public MidiParserListener
// =======================================================================
{
   // -Wweak-vtables ???
};

// =======================================================================
struct MidiParserTest
// =======================================================================
{
   // DE_CREATE_LOGGER("de.MidiFileListenerTest")

   static void
   test()
   {
      testFile("../../media/lost.mid");
   }

   static bool
   testFile( std::string loadUri )
   {
      ByteVector bv;

      if ( !MidiUtil::loadByteVector( bv, loadUri ) )
      {
         std::cout << "Error: no loadUri" << std::endl;
         return false;
      }

      std::cout << "MidiParser.parse(" << loadUri << ")" << std::endl;

      MidiParser parser;
      MidiParserConsolePrinterListener listener;
      parser.addListener( &listener );

      //PerformanceTimer perf;
      //perf.start();
      size_t const expect = bv.size();
      size_t const result = parser.parse( bv.data(), bv.data() + bv.size(), loadUri );
      //perf.stop();
      if ( result != expect )
      {
         std::cout << "ERROR :: Parser failed somewhere, result(" << result << "), expect(" << expect << ")" << std::endl;
      }
      else
      {
         std::cout << "OK :: Parsed everything, bytes(" << result << ")." << std::endl;
      }
      //DE_DEBUG("MidiParser needed ", perf.ms(), " ms, loadUri = ", loadUri )

      return true;
   }
};

} // end namespace de


