#pragma once
#include "MidiParser.hpp"
#include "MidiFile.hpp"
#include <assert.h>
#include <DarkImage.hpp>

namespace de {

//------------------------------------------------------------------------
// MIDI Clock Information:
//------------------------------------------------------------------------
//
// + microseconds per tick = microseconds per quarter note / ticks per quarter note
//
// + ticks = resolution * (1 / tempo) * 1000 * elapsed_time
//
// - resolution in ticks/beat (or equivalently ticks/Quarter note).
//   This fixes the smallest time interval to be generated.
// - tempo in microseconds per beat,
//   which determines how many ticks are generated in a set time interval.
// - elapsed_time which provides the fixed timebase for playing the midi events.
//
//    ticks   ticks   beat   1000 us    ms
//    ----- = ----- * ---- * ------- * ----
//    time    beat     us       ms     time
//
// - time is the elapsed time between calls to the tick generator. This must be calculated by the tick generator based on the history of the previous call to the tick generator.
// - tempo is the tempo determined by the Set Tempo MIDI event. Note this event only deals in Quarter Notes.
// - resolution is held as TicksPerQuarterNote.
//

// =======================================================================
struct DurationComputer : public MidiParserListener
// =======================================================================
{
   int m_ticksPerQuarterNote = 96; // = ticks per beat
   int m_top = 4;
   int m_bottom = 4;
   int m_clocksPerBeat = 24;
   int m_n32rd_per_beat = 8;
   int m_microsecondsPerQuarterNote = 646000; // = microseconds per beat

   std::vector< MidiSetTempoEvent > m_setTempoEvents;

   u64 m_tickMin = std::numeric_limits< u64 >::max();
   u64 m_tickMax = std::numeric_limits< u64 >::lowest();

   DurationComputer() {}
   ~DurationComputer() override {}

   void mpHeader( int fileType, int trackCount, int ticksPerQuarterNote ) override
   {
      (void)fileType;
      (void)trackCount;
      m_ticksPerQuarterNote = ticksPerQuarterNote;
   }

   // Finalize duration of last SetTempo() event
   void mpEnd() override
   {
      size_t const eventCount = m_setTempoEvents.size();

      // Insert atleast one SetTempoEvent that spans entire song.
      if ( eventCount == 0 )
      {
         MidiSetTempoEvent e = MidiSetTempoEvent::fromBPM( 0, 90.0 ); // default MIDI bpm value.
         e.m_duration = s64( m_tickMax );
         m_setTempoEvents.emplace_back( std::move(e) );
      }
      // or finalize last SetTempo event's duration.
      else if ( eventCount == 1 )
      {
         MidiSetTempoEvent & e = m_setTempoEvents.back();
         e.m_duration = s64( m_tickMax );
      }
      // or finalize last SetTempo event's duration using its predecessor event.
      else
      {
         MidiSetTempoEvent & e = m_setTempoEvents.back();
         e.m_duration = s64( m_tickMax ) - s64( e.m_tick );
      }

      std::cout << "eventCount == " << eventCount << std::endl;
   }

   void mpSetTempo( u64 tick, float beatsPerMinute, int microsecondsPerQuarterNote ) override
   {
      (void)beatsPerMinute;

      // Insert a new first tempo event, if tick > 0
      /* Makes the duration incorrect longer
      if ( m_setTempoEvents.size() == 0 && tick > 0 )
      {
         MidiSetTempoEvent e;
         e.m_tick = 0;
         e.m_microsecondsPerQuarterNote = microsecondsPerQuarterNote;
         m_setTempoEvents.emplace_back( std::move(e) );
      }
      */

      // Finalize duration of last event ( before pushing a new event )
      if ( m_setTempoEvents.size() > 0 )
      {
         MidiSetTempoEvent & back = m_setTempoEvents.back();
         back.m_duration = s64(tick) - s64(back.m_tick);
      }

      // Push new event to back.
      MidiSetTempoEvent e;
      e.m_tick = tick;
      e.m_microsecondsPerQuarterNote = microsecondsPerQuarterNote;
      m_setTempoEvents.emplace_back( std::move(e) );
   }

   void mpTimeSignature( u64 tick, int top, int bottom, int clocksPerBeat, int n32rd_per_beat ) override
   {
      (void)tick;
      m_top = top;
      m_bottom = bottom;
      m_clocksPerBeat = clocksPerBeat;
      m_n32rd_per_beat = n32rd_per_beat;
   }

   void mpNoteOn( u64 tick, int channel, int midiNote, int velocity ) override
   {
      m_tickMin = std::min( m_tickMin, tick );
      m_tickMax = std::max( m_tickMax, tick );
      (void)channel;
      (void)midiNote;
      (void)velocity;
   }

   void mpNoteOff( u64 tick, int channel, int midiNote, int velocity ) override
   {
      m_tickMin = std::min( m_tickMin, tick );
      m_tickMax = std::max( m_tickMax, tick );
      (void)channel;
      (void)midiNote;
      (void)velocity;
   }

   // + f64 beatsPerMinute = (60 * 1000 * 1000) / microsPerQuarterNote;
   //
   // + f64 microsPerQuarterNote = (60 * 1000 * 1000) / bpm;
   //
   // + f64 microsPerTick = microsPerQuarterNote / ticksPerQuarterNote;
   //
   // + f64 secondsPerTick = microsPerQuarterNote / 1000000.0 / ticksPerQuarterNote
   //                      = microsPerQuarterNote /(1000000.0 * ticksPerQuarterNote)
   // + f64 ticks = resolution * (1 / tempo) * 1000 * elapsed_time
   //

   // getTempoBPM -- Returns the tempo in terms of beats per minute.
   //                return 60000000.0 / (double)microseconds;
   // getTempoTPS -- Returns the tempo in terms of ticks per seconds.
   //                return tpq * 1000000.0 / (double)microseconds;
   // getTempoSPT -- Returns the tempo in terms of seconds per tick.
   //                return (double)microseconds / 1000000.0 / tpq;
/*
   void fillDurations()
   {
      std::cout << "Orignal.SetTempoEvents = " << m_setTempoEvents.size() << std::endl;
      for ( size_t i = 0; i < m_setTempoEvents.size(); ++i )
      {
         std::cout << "Orignal.SetTempoEvent["<<i<<"] " << m_setTempoEvents[i].toString() << std::endl;
      }

      if ( m_tickMax < 1 )
      {
         std::cout << "ERROR m_tickMax < 1" << std::endl;
         return;
      }

      if ( m_setTempoEvents.size() == 0 )
      {
         std::cout << "WARN: Push atleast one SetTempo event" << std::endl;
         MidiSetTempoEvent e = MidiSetTempoEvent::fromBPM( 0, 90.0 ); // default bpm, starts at 0.
         m_setTempoEvents.emplace_back( std::move( e ) );
      }

      if ( m_setTempoEvents[0].m_tick > 0 )
      {
         std::cout << "WARN: Insert additional SetTempo event (tickStart > 0)" << std::endl;
         MidiSetTempoEvent e = MidiSetTempoEvent::fromBPM( 0, 90.0 ); // default bpm, starts at 0.
         m_setTempoEvents.insert( m_setTempoEvents.begin(), e );
      }

      // Now insert durations:

      if ( m_setTempoEvents.size() == 1 )
      {
         m_setTempoEvents[0].m_duration = s64(m_tickMax);
      }
      else
      {
         for ( size_t i = 1; i < m_setTempoEvents.size(); ++i )
         {
            s64 tickBeg = s64(m_setTempoEvents[i-1].m_tick);
            s64 tickEnd = s64(m_setTempoEvents[i].m_tick);
            s64 duration = tickEnd - tickBeg;

            if ( duration > 0 )
            {
               m_setTempoEvents[i-1].m_duration = duration;
            }
            else
            {
               std::cout << "ERROR: ["<<i<<"] Got bad duration " << duration << ", "
                  "we should delete this entry, since it has no influence, "
                  "but makes our life more complicated!" << std::endl;
               m_setTempoEvents[i-1].m_duration = 0;
            }
         }

         s64 tickBeg = s64(m_setTempoEvents.back().m_tick);
         s64 tickEnd = s64(m_tickMax);
         s64 duration = tickEnd - tickBeg;
         if ( duration > 0 )
         {
            m_setTempoEvents.back().m_duration = duration;
         }
         else
         {
            std::cout << "ERROR: [back] Got bad duration " << duration << std::endl;
            m_setTempoEvents.back().m_duration = 0;
         }
      }
   }
*/
   f64 computeDurationInSeconds()
   {
      // fillDurations();

      // Debug SetTempo events:

      std::cout << "TicksPerQuarterNote = " << m_ticksPerQuarterNote << std::endl;
      std::cout << "TickMax = " << m_tickMax << std::endl;
      std::cout << "TickMin = " << m_tickMin << std::endl;

      std::cout << "SetTempoEvents = " << m_setTempoEvents.size() << std::endl;
      for ( size_t i = 0; i < m_setTempoEvents.size(); ++i )
      {
         std::cout << "SetTempoEvent["<<i<<"] " << m_setTempoEvents[i].toString() << std::endl;
      }

      std::cout << "TimeSignature = " << m_top << "/" << m_bottom <<
                  ", ClocksPerBeat = " << m_clocksPerBeat <<
                  ", Num32rdPerBeat = " << m_n32rd_per_beat << std::endl;

      if ( m_tickMax == 0 )
      {
         std::cout << "ERROR: Song has duration 0" << std::endl;
         return 0.0;
      }

      if ( m_setTempoEvents.size() == 0 )
      {
         std::cout << "ERROR: No SetTempo event" << std::endl;
         return 0.0;
      }

      f64 durationInSeconds = 0.0;

      for ( size_t i = 0; i < m_setTempoEvents.size(); ++i )
      {
         durationInSeconds += m_setTempoEvents[i].computeDurationInSeconds( m_ticksPerQuarterNote );
      }

      std::cout << "Duration = " << durationInSeconds << "sec" << std::endl;
      std::cout << "Duration = " << MidiUtil::strTime( durationInSeconds ) << std::endl;
      return durationInSeconds;
   }

};

} // end namespace de
