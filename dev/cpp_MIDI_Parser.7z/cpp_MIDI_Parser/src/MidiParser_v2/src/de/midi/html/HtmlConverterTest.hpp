#pragma once
#include "MidiFileListener.hpp"
#include "HtmlConverter.hpp"

namespace de {

// =======================================================================
struct HtmlConverterTest
// =======================================================================
{
   DE_CREATE_LOGGER("HtmlConverterTest")

   static void
   test()
   {
      convert( "../../media/midi/But not tonight - Depeche Mode_4_14.mid" );
      convert( "../../media/midi/porcelain_moby_davebulow_4_07.mid" ); //
      convert( "../../media/midi/hotelcal_6_37.mid" ); //
      convert( "../../media/midi/gigidagostino_illflywithyou_joerock_5_03.mid" ); //
      convert( "../../media/midi/thank_you_50_12.mid" ); //
      //convert( "../../media/midi/lost_3_34.mid" );
      //convert( "../../media/midi/Bitter Sweet Symphony_4_16.mid" ); //
      //convert( "../../media/midi/mmm_3_43.mid" ); //
   }

   static void
   work()
   {
      std::string loadUri = dbOpenFileDlg(
         "Midi2HtmlConverter wants a midi file (.mid, .midi, .smf ) | (c) 2023 by <benjaminhampe@gmx.de>");

      std::string saveUri = FileSystem::fileName(loadUri) + ".html";

      convert( loadUri, saveUri );

      // Open your local html browser
      std::stringstream ss;
      ss << "\"" << saveUri << "\"";  // Add Quotation marks for uris with spaces.
      std::string command = ss.str();
      std::cout << "Run command " << command << std::endl;
      system( command.c_str() );
   }

   static bool
   convert( std::string loadUri, std::string saveUri = "" )
   {
      if ( saveUri.empty() )
      {
         saveUri = FileSystem::fileName(loadUri) + ".html";
      }

      // (c) 2022 by <benjaminhampe@gmx.de>
      // What loads the midi HDD/SSD file completely into RAM memory.
      ByteVector bv;

      if ( !MidiUtil::loadByteVector( bv, loadUri ) )
      {
         std::cout << "Error: Cant load " << loadUri << std::endl;
         return false;
      }

      MidiFile file;
      MidiFileListener listener;
      listener.m_file = &file;

      MidiParser parser;
      parser.addListener( &listener );

      size_t expect = bv.size();
      size_t result = parser.parse( bv.data(), bv.data() + expect, loadUri );
      if ( expect != result )
      {
         std::cout << "Parser had error expect(" << expect << ") != result("<<result<<")" <<std::endl;
      }

      return HtmlConverter::convert( saveUri, file );
   }

};

} // end namespace de
