#pragma once
#include "MidiParser.hpp"
#include "MidiFile.hpp"
#include <assert.h>

namespace de {

// =======================================================================
struct MidiFileListener : public MidiParserListener
// =======================================================================
{
   MidiFile* m_file;
   MidiTrack m_track; // current Track

   MidiFileListener() : m_file(nullptr) {}
   ~MidiFileListener() override {}

// I.:

   void mpStart( u8 const* beg, u8 const* end, STR const & fileName ) override
   {
      (void)beg;
      (void)end;
      if ( !m_file )
      {
         std::runtime_error("No MidiFile pointer");
      }
      m_file->reset();
      m_file->m_fileName = fileName;
   }

   void mpEnd() override
   {
      // Nothing todo (yet)
   }
// II.:

   void mpHeader( int fileType, int trackCount, int ticksPerQuarterNote ) override
   {
      m_file->m_fileType = fileType;
      m_file->m_trackCount = trackCount;
      m_file->m_ticksPerQuarterNote = ticksPerQuarterNote;
   }

   void mpTrackStart( int trackNumber ) override
   {
      m_track = MidiTrack( trackNumber );
   }

   void mpTrackEnd() override
   {
      m_file->m_tracks.emplace_back( std::move( m_track ) );
   }

// III.:

   void mpSetTempo( u64 tick, float beatsPerMinute, int microsecondsPerQuarterNote ) override
   {
      (void)beatsPerMinute; // = 60 000 000 / microsecondsPerQuarterNote;
      MidiSetTempoEvent setTempoEvent;
      setTempoEvent.m_tick = tick;
      setTempoEvent.m_microsecondsPerQuarterNote = microsecondsPerQuarterNote;
      m_track.m_setTempoEvents.emplace_back( std::move(setTempoEvent) );
   }

   void mpTimeSignature( u64 tick, int top, int bottom, int clocksPerBeat, int n32rd_per_beat ) override
   {
      MidiTimeSignatureEvent timeSignatureEvent;
      timeSignatureEvent.m_tick = tick;
      timeSignatureEvent.m_top = top;
      timeSignatureEvent.m_bottom = bottom;
      timeSignatureEvent.m_clocksPerBeat = clocksPerBeat;
      timeSignatureEvent.m_n32rdPerBar = n32rd_per_beat;
      m_track.m_timeSignatureEvents.emplace_back( std::move(timeSignatureEvent) );
   }
   void mpKeySignature( u64 tick, int tonart_c_offset, int minor ) override
   {
      MidiKeySignatureEvent keySignatureEvent;
      keySignatureEvent.m_tick = tick;
      keySignatureEvent.m_cdur_offset = tonart_c_offset;
      keySignatureEvent.m_minor = minor;
      m_track.m_keySignatureEvents.emplace_back( std::move(keySignatureEvent) );
   }

/*
   void mpSMPTEOffset( u64 tick, int hh, int mm, int ss, int fc, int sf ) override
   {
      (void)tick;
      (void)hh;
      (void)mm;
      (void)ss;
      (void)fc;
      (void)sf;

   }
*/
   void mpNoteOn( u64 tick, int channel, int midiNote, int velocity ) override
   {
      MidiNote note;
      note.m_channel = channel;
      note.m_midiNote = midiNote;
      note.m_attack = velocity;
      note.m_attackMs = tick;
      note.m_release = velocity;
      note.m_releaseMs = tick;
      m_track.getChannel(channel).addNote( note );
   }
   void mpNoteOff( u64 tick, int channel, int midiNote, int velocity ) override
   {
      MidiNote* note = m_track.getChannel(channel).getLastNote( midiNote );
      if ( !note )
      {
         std::cout << "Last note not found." << std::endl;
         //DE_ERROR("No last note to finish ch(",select,"), midiNote(",midiNote,"), release(",velocity,")" )
         return;
      }
      note->m_releaseMs = tick;
      note->m_release = velocity;
   }
   void mpProgramChange( u64 tick, int channel, int program ) override
   {
      (void)tick;
      m_track.getChannel(channel).m_instrument = program;
   }
   void mpControlChange( u64 tick, int channel, int cc, int value ) override
   {
      MidiControllerEvent mce;
      mce.m_tick = tick;
      mce.m_cc = cc;
      mce.m_value = value;
      m_track.getChannel(channel).getController(cc).addEvent( mce );
   }
   void mpPolyphonicAftertouch( u64 tick, int value ) override
   {
      MidiControllerEvent e;
      e.m_tick = tick;
      e.m_value = value;
      m_track.m_polyphonicAftertouch.m_events.emplace_back( std::move(e) );
   }
   void mpChannelAftertouch( u64 tick, int channel, int value ) override
   {
      MidiControllerEvent e;
      e.m_tick = tick;
      e.m_value = value;
      m_track.getChannel(channel).m_channelAftertouch.m_events.emplace_back( std::move(e) );
   }
   void mpPitchBend( u64 tick, int channel, int value ) override
   {
      MidiControllerEvent e;
      e.m_tick = tick;
      e.m_value = value;
      m_track.getChannel(channel).m_pitchBend.m_events.emplace_back( std::move(e) );
   }
/*
   void mpSequenceNumber( u64 tick, int sequenceNumber ) override
   {
      (void)tick;
      (void)sequenceNumber;
   }
   void mpChannelPrefix( u64 tick, int channelPrefix ) override
   {
      (void)tick;
      (void)channelPrefix;
   }
   void mpPortDisplay( u64 tick, int port ) override
   {
      (void)tick;
      (void)port;
   }
*/
   void mpMetaText( u64 tick, STR const & metaText ) override
   {
      if ( m_track.m_trackName.empty() )
      {
         m_track.m_trackName = metaText;
      }

      MidiMetaEvent e;
      e.m_tick = tick;
      e.m_meta = 0;
      e.m_text = metaText;
      m_track.m_textEvents.emplace_back( std::move(e) );
   }
   void mpMetaCopyright( u64 tick, STR const & metaText ) override
   {
      if ( m_track.m_trackName.empty() )
      {
         m_track.m_trackName = metaText;
      }

      MidiMetaEvent e;
      e.m_tick = tick;
      e.m_meta = 0;
      e.m_text = metaText;
      m_track.m_textEvents.emplace_back( std::move(e) );
   }
   void mpMetaTrackName( u64 tick, STR const & metaText ) override
   {
      if ( m_track.m_trackName.empty() )
      {
         m_track.m_trackName = metaText;
      }

      MidiMetaEvent e;
      e.m_tick = tick;
      e.m_meta = 0;
      e.m_text = metaText;
      m_track.m_textEvents.emplace_back( std::move(e) );
   }
   void mpMetaInstrumentName( u64 tick, STR const & metaText ) override
   {
      MidiMetaEvent e;
      e.m_tick = tick;
      e.m_meta = 0;
      e.m_text = metaText;
      m_track.m_textEvents.emplace_back( std::move(e) );
   }
   void mpMetaLyric( u64 tick, STR const & metaText ) override
   {
      MidiMetaEvent e;
      e.m_tick = tick;
      e.m_meta = 0;
      e.m_text = metaText;
      m_track.m_lyricEvents.emplace_back( std::move(e) );
   }
   void mpMetaMarker( u64 tick, STR const & metaText ) override
   {
      MidiMetaEvent e;
      e.m_tick = tick;
      e.m_meta = 0;
      e.m_text = metaText;
      m_track.m_textEvents.emplace_back( std::move(e) );
   }
   void mpMetaCuePoint( u64 tick, STR const & metaText ) override
   {
      MidiMetaEvent e;
      e.m_tick = tick;
      e.m_meta = 0;
      e.m_text = metaText;
      m_track.m_textEvents.emplace_back( std::move(e) );
   }
   void mpMetaProgramName( u64 tick, STR const & metaText ) override
   {
      MidiMetaEvent e;
      e.m_tick = tick;
      e.m_meta = 0;
      e.m_text = metaText;
      m_track.m_textEvents.emplace_back( std::move(e) );
   }
   void mpMetaDeviceName( u64 tick, STR const & metaText ) override
   {
      MidiMetaEvent e;
      e.m_tick = tick;
      e.m_meta = 0;
      e.m_text = metaText;
      m_track.m_textEvents.emplace_back( std::move(e) );
   }
};

} // end namespace de


/*
   static void
   test()
   {
      DE_DEBUG("Test")

      Image img;
      img.resize( 600, 600 );
      img.fill( 0xFF202020 );

      ImagePainter::drawCircle( img, Recti(1,1,13,8), 0xFFFF0000 );
      ImagePainter::drawCircleBorder( img, Recti(14,1,13,8), 0xFF00FFFF );

      ImagePainter::drawCircle( img, Recti(1,10,12,6), 0xFFFF00FF );
      ImagePainter::drawCircleBorder( img, Recti(13,10,12,6), 0xFF00FFFF );

      ImagePainter::drawCircle( img, Recti(1,20,11,7), 0xFFFF00FF );
      ImagePainter::drawCircleBorder( img, Recti(12,20,11,7), 0xFF00FFFF );
      dbSaveImage( img, "MidiImageWriter_Ellipse.png");
   }

   void
   save( std::string saveUri, std::string title, std::string mediaDir = "" )
   {
//      std::ostringstream o;
//      std::ofstream file( saveUri.c_str() );
//      if ( file.is_open() )
//      {
//         std::string htmlStr = o.str();
//         file << htmlStr;
//         file.close();

//         DE_DEBUG("Saved HTML ", saveUri, " with ", htmlStr.size(), " bytes.")
//      }
   }

   */
