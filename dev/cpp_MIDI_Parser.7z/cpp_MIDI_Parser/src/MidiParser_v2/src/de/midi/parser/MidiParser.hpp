#pragma once
#include "GeneralMidi.hpp"  // General Midi benni defines
#include "MidiParserListener.hpp"
//#include <DarkImage.hpp>  // DE_CREATE_LOGGER

namespace de {

// SMF Syntax - Standard Midi file syntax. ( Aufs Byte genau leider )
// <descriptor:length> means 'length' bytes, MSB first
// <descriptor:v> means variable length argument (special format)
// SMF := <header_chunk> + <track_chunk> [ + <track_chunk> ... ]
// header chunk := "MThd" + <header_length:4> + <format:2> + <num_tracks:2> + <time_division:2>
// track_chunk := "MTrk" + <length:4> + <track_event> [ + <track_event> ... ]
// track_event := <time:v> + [ <midi_event> | <meta_event> | <sysex_event> ]
// midi_event := any MIDI channel message, including running status
// meta_event := 0xFF + <meta_type:1> + <length:v> + <event_data_bytes>
// sysex_event := 0xF0 + <len:1> + <data_bytes> + 0xF7
// sysex_event := 0xF7 + <len:1> + <data_bytes> + 0xF7

// =======================================================================
struct MidiParser
// =======================================================================
{
   //DE_CREATE_LOGGER("de.midi.MidiParser")

   //<header>
   //0-the file contains a single multi-channel track
   //1-the file contains one or more simultaneous tracks (or MIDI outputs) of a sequence
   //2-the file contains one or more sequentially independent single-track patterns
   u16 m_fileType;   // Can be removed. Always 1 for a format 0 file, else number of tracks.
   u16 m_trackCount; // Can be removed
   u16 m_resolution; // Can be removed, ticks per quarter-note
   //</header>
   //<statemachine>
   u16 m_trackIndex = 0;
   u8 m_runStatus = 0;
   u64 m_currTick = 0; // absolute tick, not a delta. Helps skipping event you dont want
   //MidiClock m_clock;
   //</statemachine>

   MidiParser();
   ~MidiParser();

   void
   reset();

   size_t
   parse( u8 const* const beg, u8 const* const end, STR const & uri );

   // Must always return 14 (bytes).
   size_t
   parseFileHeader( u8 const* const beg, u8 const* const end );

   // Must always return 8 (bytes).
   size_t
   parseTrackHeader( u8 const* const beg, u8 const* const end, uint32_t & dataSize );

   size_t
   parseTrackData( u8 const* const beg, u8 const* const end );

   size_t
   parseEvent( u8 const* const beg, u8 const* const end );

   size_t
   parseMetaEvent(
      u8 const* const vt, // Event start ( time ), needed for full token extract
      u8 const* const beg, // Current pos (after reading byte metatype).
      u8 const* const end, // End of string
      uint32_t deltaTime, // Already parsed dt injected here
      u8 metatype    // Already parsed metatype injected here
   );

   STR
   parseMetaText( u8 const* const beg, u8 const* const end );


   // =======================================================================
   //struct MidiParserListenerRegistry
   // =======================================================================

   std::vector< MidiParserListener* > m_listeners; // One and only member

   // ~MidiParserListenerRegistry() {}

   // Removes all listeners at once.
   // Simpler than having a removeListener() function.
   void clearListeners()
   {
      m_listeners.clear();
   }

   // Adds/registers a listener, rejects null pointers.
   void addListener( MidiParserListener* listener )
   {
      if ( !listener ) return;
      m_listeners.emplace_back( listener );
   }

// I.:

   void mpStart( u8 const* beg, u8 const* end, STR const & fileName )
   {
      for (auto l : m_listeners) { if (l) l->mpStart( beg, end, fileName ); }
   }
   void mpEnd()
   {
      for (auto l : m_listeners) { if (l) l->mpEnd(); }
   }
   void mpToken( u8 const* beg, u8 const* end, STR const & comment )
   {
      for (auto l : m_listeners) { if (l) l->mpToken( beg, end, comment ); }
   }
   void mpTrack( u8 const* beg, u8 const* end, int trackNumber )
   {
      for (auto l : m_listeners) { if (l) l->mpTrack( beg, end, trackNumber ); }
   }

// II.:

   void mpHeader( int fileType, int trackCount, int ticksPerQuarterNote )
   {
      for (auto l : m_listeners) { if (l) l->mpHeader( fileType, trackCount, ticksPerQuarterNote ); }
   }
   void mpTrackStart( int trackIndex )
   {
      for (auto l : m_listeners) { if (l) l->mpTrackStart( trackIndex ); }
   }
   void mpTrackEnd()
   {
      for (auto l : m_listeners) { if (l) l->mpTrackEnd(); }
   }

// III.:

   void mpNoteOn( u64 tick, int channel, int midiNote, int velocity )
   {
      for (auto l : m_listeners) { if (l) l->mpNoteOn( tick, channel, midiNote, velocity ); }
   }
   void mpNoteOff( u64 tick, int channel, int midiNote, int velocity )
   {
      for (auto l : m_listeners) { if (l) l->mpNoteOff( tick, channel, midiNote, velocity ); }
   }
   void mpPolyphonicAftertouch( u64 tick, int value )
   {
      for (auto l : m_listeners) { if (l) l->mpPolyphonicAftertouch( tick, value ); }
   }
   void mpChannelAftertouch( u64 tick, int channel, int value )
   {
      for (auto l : m_listeners) { if (l) l->mpChannelAftertouch( tick, channel, value ); }
   }
   void mpPitchBend( u64 tick, int channel, int value )
   {
      for (auto l : m_listeners) { if (l) l->mpPitchBend( tick, channel, value ); }
   }
   void mpProgramChange( u64 tick, int channel, int program )
   {
      for (auto l : m_listeners) { if (l) l->mpProgramChange( tick, channel, program ); }
   }
   void mpControlChange( u64 tick, int channel, int cc, int value )
   {
      for (auto l : m_listeners) { if (l) l->mpControlChange( tick, channel, cc, value ); }
   }
   void mpSetTempo( u64 tick, float beatsPerMinute, int microsecondsPerTick )
   {
      for (auto l : m_listeners) { if (l) l->mpSetTempo( tick, beatsPerMinute, microsecondsPerTick ); }
   }
   void mpSMPTEOffset( u64 tick, int hh, int mm, int ss, int fc, int sf )
   {
      for (auto l : m_listeners) { if (l) l->mpSMPTEOffset( tick, hh, mm, ss, fc, sf ); }
   }
   void mpTimeSignature( u64 tick, int top, int bottom, int clocksPerBeat, int n32rd_per_beat )
   {
      for (auto l : m_listeners) { if (l) l->mpTimeSignature( tick, top, bottom, clocksPerBeat, n32rd_per_beat ); }
   }
   void mpKeySignature( u64 tick, int tonart_c_offset, int minor )
   {
      for (auto l : m_listeners) { if (l) l->mpKeySignature( tick, tonart_c_offset, minor ); }
   }
   void mpSequenceNumber( u64 tick, int sequenceNumber )
   {
      for (auto l : m_listeners) { if (l) l->mpSequenceNumber( tick, sequenceNumber ); }
   }
   void mpChannelPrefix( u64 tick, int channelPrefix )
   {
      for (auto l : m_listeners) { if (l) l->mpChannelPrefix( tick, channelPrefix ); }
   }
   void mpPortDisplay( u64 tick, int port )
   {
      for (auto l : m_listeners) { if (l) l->mpPortDisplay( tick, port ); }
   }
   /*
   void mpMeta( u64 tick, int metaType, STR const & metaText )
   {
      for (auto l : m_listeners) { if (l) l->mpMeta( tick, metaType, metaText ); }
   }
   */
   void mpMetaText( u64 tick, STR const & metaText )
   {
      for (auto l : m_listeners) { if (l) l->mpMetaText( tick, metaText ); }
   }
   void mpMetaCopyright( u64 tick, STR const & metaText )
   {
      for (auto l : m_listeners) { if (l) l->mpMetaCopyright( tick, metaText ); }
   }
   void mpMetaTrackName( u64 tick, STR const & metaText )
   {
      for (auto l : m_listeners) { if (l) l->mpMetaTrackName( tick, metaText ); }
   }
   void mpMetaInstrumentName( u64 tick, STR const & metaText )
   {
      for (auto l : m_listeners) { if (l) l->mpMetaInstrumentName( tick, metaText ); }
   }
   void mpMetaLyric( u64 tick, STR const & metaText )
   {
      for (auto l : m_listeners) { if (l) l->mpMetaLyric( tick, metaText ); }
   }
   void mpMetaMarker( u64 tick, STR const & metaText )
   {
      for (auto l : m_listeners) { if (l) l->mpMetaMarker( tick, metaText ); }
   }
   void mpMetaCuePoint( u64 tick, STR const & metaText )
   {
      for (auto l : m_listeners) { if (l) l->mpMetaCuePoint( tick, metaText ); }
   }
   void mpMetaProgramName( u64 tick, STR const & metaText )
   {
      for (auto l : m_listeners) { if (l) l->mpMetaProgramName( tick, metaText ); }
   }
   void mpMetaDeviceName( u64 tick, STR const & metaText )
   {
      for (auto l : m_listeners) { if (l) l->mpMetaDeviceName( tick, metaText ); }
   }
};

} // end namespace de
