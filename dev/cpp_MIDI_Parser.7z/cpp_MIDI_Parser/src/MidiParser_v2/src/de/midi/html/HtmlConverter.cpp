#include "HtmlConverter.hpp"

namespace de {

// static
bool
HtmlConverter::convert( std::string saveUri, MidiFile const & file )
{
   /*
   std::vector< std::string > imageFiles;
   for ( size_t i = 0; i < file.m_tracks.size(); ++i )
   {
      Image img = createTrackImage( file, int(i), w, h );
      std::string imageUri = saveUri + std::to_string(i) + ".png";
      if ( dbSaveImage( img, imageUri ) )
      {
         imageFiles.emplace_back( imageUri );
      }
   }
   */
   //FileSystem::saveText( saveUri, sheetParser.m_sheet.toString() );

   std::ostringstream o;

   o << "<html>\n"
   "<title>Midi2Html: " << saveUri << "</title>\n"
   "<style type=\"text/css\">\n"
   "*    { margin:0; border:0; padding:0; }\n"
   "body { width:100%; height:100%; color:rgb(0,0,0); background-color:rgb(255,255,255); font-family:monospace; font-size:16px; }\n"
   //"caption { font-weight:bold; font-size:24px; line-height:50px; vertical-align:middle;}\n"
   "content { background-color:white; color:black; position:absolute; top:50px; padding-left:20px; padding-top:20px; white-space:nowrap; z-index:1;}\n"
   // "img { border:5px; border-color:black; padding:5px; margin:5px;}\n"
   // "div12 { width:100%; height:12px; line-height:12px; display-style:inline; }\n"
   // "h1 { color:white; background-color:rgb(0   ,0   ,0  ); font-size:64px; vertical-align:middle; font-weight:900; }\n"
   // "h2 { color:white; background-color:rgb(127 ,192 ,255); font-size:32px; vertical-align:middle; font-weight:750; }\n"
   // "h3 { color:white; background-color:rgb(192 ,200 ,255); font-size:24px; vertical-align:middle; font-weight:600; }\n"
   // "h4 { color:white; background-color:rgb(200 ,200 ,255); font-size:24px; vertical-align:middle; font-weight:600; }\n"
   // "h5 { color:black; background-color:rgb(255 ,255 ,255); font-size:16px; vertical-align:middle; font-weight:400; }\n"
   // "h6 { color:white; background-color:rgb(64  ,64  ,192); font-size:12px; vertical-align:middle; font-weight:400; }\n"
   // "hr { color:black; background-color:rgb(255 ,255 ,0); height:10px; line-height:5px; vertical-align:middle; }\n"
   // "date { color:#FF00FF; font-weight:bold; margin-left:20px;}\n"
   // "line { color:#207F20; font-weight:bold; margin-left:20px;}\n"
   // "time { color:#4040DF; font-weight:bold; margin-left:20px;}\n"
   // "trace {color:white; background-color:#00AF00; margin-left:20px;}\n"
   // "debug {color:white; background-color:#FF00FF; margin-left:20px;}\n"
   // "info { margin-left:20px; }\n"
   // "warn {color:black; background-color:yellow; margin-left:20px;}\n"
   // "error {color:white; background-color:red; margin-left:20px;}\n"
   "</style>\n</head>\n"
   "<body>\n"

   // ---------------------- title (=loadUri) ----------------------------------
   "<panel style=\"background-color:blue; position:fixed; top:0px; left:0px; width:100%; height:50px; z-index:2;\">\n"
   "<table width=\"100%\" height=\"100%\">\n"
   "<tr valign=\"middle\">"
   "<td align=\"center\">"
   "<caption style=\"color:white; font-weight:bold; font-size:16px; line-height:50px; vertical-align:middle;\">"
       << FileSystem::fileName(file.m_fileName) << "</caption></td>\n"
   "</tr>\n"
   "</table>\n"
   "</panel>\n";

   // ---------------------- content start ----------------------------------
   o << "<content>\n";

   // ---------------------- print file Header ----------------------------------

   o << "<h4>" << file.m_fileName << "</h4>\n"
        "<h4>FileType = " << file.m_fileType << "</h4>\n"
        "<h4>TrackCount = " << file.m_trackCount << "</h4>\n"
        "<h4>TicksPerQuarterNote = " << file.m_ticksPerQuarterNote << "</h4>\n"
        "<h4>ParsedTracks = " << file.m_tracks.size() << "</h4>\n"
        "<hr>\n";

   // ---------------------- Loop tracks ----------------------------------

   for ( size_t t = 0; t < file.m_tracks.size(); ++t )
   {
      o << "<br>";
      MidiTrack const & track = file.m_tracks[ t ];
      /*
      o << "<panel style=\"background-color:rgb(100,100,255); left:0px; width:100%; height:50px; z-index:2;\">\n"
      "<table width=\"100%\" height=\"100%\">\n"
      "<tr valign=\"middle\">"
      "<td align=\"center\">"
      "<caption style=\"color:white; font-weight:bold; font-size:16px; line-height:50px; vertical-align:middle;\">"
          << "Track[" << track.m_trackIndex << "/" << file.m_trackCount << "] "<< track.m_trackName << "</caption></td>\n"
      "</tr>\n"
      "</table>\n"
      "</panel>\n";
      */
      o << "<h3>Track[" << track.m_trackIndex << "/" << file.m_trackCount << "] "<< track.m_trackName << "</h3>\n";

      // Write SetTempo events:
      if ( track.m_setTempoEvents.size() )
      {
         o << "<h4>SetTempo events = " << track.m_setTempoEvents.size() << "</h4>\n";
         o << "<pre>";
         for ( size_t i = 0; i < track.m_setTempoEvents.size(); ++i )
         {
            if ( i > 0 ) o << "\n";
            o << track.m_setTempoEvents[i].toString();
         }
         o << "</pre><br>\n";
      }

      // Write TimeSignature events:
      if ( track.m_timeSignatureEvents.size() )
      {
         o << "<h4>TimeSignature events = " << track.m_timeSignatureEvents.size() << "</h4>\n";
         o << "<pre>";
         for ( size_t i = 0; i < track.m_timeSignatureEvents.size(); ++i )
         {
            if ( i > 0 ) o << "\n";
            o << track.m_timeSignatureEvents[i].toString();
         }
         o << "</pre><br>\n";
      }

      // Write KeySignature events:
      if ( track.m_keySignatureEvents.size() )
      {
         o << "<h4>KeySignature events = " << track.m_keySignatureEvents.size() << "</h4>\n";
         o << "<pre>";
         for ( size_t i = 0; i < track.m_keySignatureEvents.size(); ++i )
         {
            if ( i > 0 ) o << "\n";
            o << track.m_keySignatureEvents[i].toString();
         }
         o << "</pre><br>\n";
      }

      // Write MetaText events:
      if ( track.m_textEvents.size() )
      {
         o << "<h4>MetaText events = " << track.m_textEvents.size() << "</h4>\n";
         o << "<pre>";
         for ( size_t i = 0; i < track.m_textEvents.size(); ++i )
         {
            if ( i > 0 ) o << "\n";
            o << track.m_textEvents[i].toString();
         }
         o << "</pre><br>\n";
      }

      // Write Lyric events:
      if ( track.m_lyricEvents.size() )
      {
         o << "<h4>MetaLyric events = " << track.m_lyricEvents.size() << "</h4>\n";
         o << "<pre>";
         for ( size_t i = 0; i < track.m_lyricEvents.size(); ++i )
         {
            //if ( i > 0 ) o << " ";
            o << track.m_lyricEvents[i].m_text;
         }
         o << "</pre><br>\n";
      }

      // Write PolyphonicAftertouch events:
      if ( track.m_polyphonicAftertouch.m_events.size() )
      {
         MidiController const & cc = track.m_polyphonicAftertouch;
         o << "<h4>PolyphonicAftertouch events = " << cc.m_events.size() << "</h4>\n";
         Image img = HtmlConverterUtil::createCCImage( file, cc );
         std::string imageUri = MidiUtil::joinStr(saveUri,"_track",t,"_pat.png");
         dbSaveImage( img, imageUri );
         o << "<img src=\"./"<< FileSystem::fileName( imageUri ) << "\" "
            << "width=\""<< img.w() << "\" "<< "height=\""<< img.h() << "\" "
            "/>\n";
      }

      // Write channels:
      if ( track.m_channels.size() )
      {
         for ( size_t c = 0; c < track.m_channels.size(); ++c )
         {
            MidiChannel const & channel = track.m_channels[ c ];
            o << "<h3>Channel[" << channel.m_channelIndex << "] " << GM_toString(channel.m_instrument) << "</h3>\n";

            // Write simple editor notes: ( kinda wasteful in space, but easy to read )
            if ( channel.m_notes.size() )
            {
               o << "<h4>Notes = " << channel.m_notes.size() << "</h4>\n";

               Image img = HtmlConverterUtil::createNoteImage( file, int(t), int(c) );
               std::string imageUri = MidiUtil::joinStr(saveUri,"_track",t,"_ch",c,".png");
               dbSaveImage( img, imageUri );
               o << "<img src=\"./"<< FileSystem::fileName( imageUri ) << "\" "
                 << "width=\""<< img.w() << "\" "<< "height=\""<< img.h() << "\" "
                     "/>\n";

            }

            // Write ChannelAftertouch events:
            if ( channel.m_channelAftertouch.m_events.size() )
            {
               MidiController const & cc = channel.m_channelAftertouch;
               o << "<h4>ChannelAftertouch events = " << cc.m_events.size() << "</h4>\n";

               if ( cc.m_events.size() > 4 )
               {
                  Image img = HtmlConverterUtil::createCCImage( file, cc );
                  std::string imageUri = MidiUtil::joinStr(saveUri,"_track",t,"_ch",c,"_cat.png");
                  dbSaveImage( img, imageUri );
                  o << "<img src=\"./"<< FileSystem::fileName( imageUri ) << "\" "
                     << "width=\""<< img.w() << "\" "<< "height=\""<< img.h() << "\" "
                     "/>\n";
               }
               else
               {
                  o << "<pre>";
                  for ( size_t i = 0; i < cc.m_events.size(); ++i )
                  {
                     if ( i > 0 ) o << "\n";
                     o << cc.m_events[i].toString();
                  }
                  o << "</pre>\n";
               }
            }

            // Write PitchBend events:
            if ( channel.m_pitchBend.m_events.size() )
            {
               MidiController const & cc = channel.m_pitchBend;
               o << "<h4>PitchBend events = " << cc.m_events.size() << "</h4>\n";

               if ( cc.m_events.size() > 2 )
               {
                  Image img = HtmlConverterUtil::createPitchBendImage( file, cc );
                  std::string imageUri = MidiUtil::joinStr(saveUri,"_track",t,"_ch",c,"_pitchbend.png");
                  dbSaveImage( img, imageUri );
                  o << "<img src=\"./"<< FileSystem::fileName( imageUri ) << "\" "
                     << "width=\""<< img.w() << "\" "<< "height=\""<< img.h() << "\" />\n";
               }
               else
               {
                  o << "<pre>";
                  for ( size_t i = 0; i < cc.m_events.size(); ++i )
                  {
                     if ( i > 0 ) o << "\n";
                     o << cc.m_events[i].toString();
                  }
                  o << "</pre>\n";
               }
            }

            // Write CC events:
            if ( channel.m_controller.size() )
            {
               for ( size_t j = 0; j < channel.m_controller.size(); ++j )
               {
                  MidiController const & cc = channel.m_controller[ j ];

                  o << "<h4>Controller["<<j+1<<"/"<<channel.m_controller.size()<<"] "
                    << CC_toString(cc.m_cc)<<", events("<<cc.m_events.size()<<")</h4>\n";

                  if ( cc.m_events.size() > 4 )
                  {
                     Image img = HtmlConverterUtil::createCCImage( file, int(t), int(c), int(j) );
                     std::string imageUri = MidiUtil::joinStr(saveUri,"_track",t,"_ch",c,"_cc",j,".png");
                     dbSaveImage( img, imageUri );
                     o << "<img src=\"./"<< FileSystem::fileName( imageUri ) << "\" "
                           "width=\""<< img.w() << "\" "<< "height=\""<< img.h() << "\" />\n";
                  }
                  else if ( cc.m_events.size() > 0 )
                  {
                     o << "<pre>";
                     for ( size_t i = 0; i < cc.m_events.size(); ++i )
                     {
                        if ( i > 0 ) o << "\n";
                        o << cc.m_events[0].toString();
                     }
                     o << "</pre>\n";
                  }
               }
            }

         }
         //o << "<br>";
      }
      //o << "<br>";
   }

   //o << "<br>";


   // ---------------------- image table ----------------------------------
   /*
   o <<
   "<table cellspacing=\"5\" cellpadding=\"5\">\n";

   for ( size_t i = 0; i < imageFiles.size(); ++i )
   {
      std::string uri = imageFiles[i];

      o << "<tr><td><img src=\"./"<< FileSystem::fileName( uri ) << "\" /></td></tr>\n";
   }

   o <<
   "</table>\n"
   */


   // ---------------------- content end ----------------------------------

   o << "<br><br><br><br><br></content>\n"

   // ---------------------------- footer ----------------------------------

   "<footer style=\"background-color:blue; color:white; position:fixed; bottom:0px; left:0px; width:100%; height:50px; line-height:50px; z-index:3;\">\n"
   "<table width=\"100%\" height=\"100%\">\n"
   "<tr valign=\"middle\"><td align=\"center\"><h3 style=\"color:white;\">File produced by class Midi2HtmlConverter</h3></td></tr>\n"
   "<tr valign=\"middle\"><td align=\"center\"><h6 style=\"color:white;\">(c) 2023 by BenjaminHampe@gmx.de</h6></td></tr>\n"
   "</table>\n"
   "</footer>\n"
   "</body>\n"
   "</html>\n";

   std::ofstream f( saveUri.c_str() );
   if ( f.is_open() )
   {
      std::string htmlStr = o.str();
      f << htmlStr;
      f.close();

      DE_DEBUG("Saved HTML ", saveUri, " with ", htmlStr.size(), " bytes.")
   }

   return true;
}

} // end namespace de
