#pragma once
#include "MidiParserListener.hpp"

namespace de {

// =======================================================================
struct ConsolePrinter : public MidiParserListener
// =======================================================================
{
   ConsolePrinter() {}
   ~ConsolePrinter() override {}

// I.:

   void mpStart( u8 const* beg, u8 const* end, STR const & fileName ) override
   {
      std::cout << "mpStart(" << fileName << ")" << std::endl;
   }
   void mpEnd() override
   {
      std::cout << "mpEnd()" << std::endl;
   }
   void mpToken( u8 const* beg, u8 const* end, STR const & comment ) override
   {
      std::cout << "mpToken(" << (void*)beg << "," << size_t(end - beg) << "," << comment << ")" << std::endl;
   }
   void mpTrack( u8 const* beg, u8 const* end, int trackNumber ) override
   {
      std::cout << "mpTrack("<<trackNumber<<")" << std::endl;
   }

// II.:

   void mpHeader( int fileType, int trackCount, int ticksPerQuarterNote ) override
   {
      std::cout << "mpHeader(" << fileType << "," << trackCount << "," << ticksPerQuarterNote << ")" << std::endl;
   }
   void mpTrackStart( int trackNumber ) override
   {
      std::cout << "mpTrackStart("<<trackNumber<<")" << std::endl;
   }
   void mpTrackEnd() override
   {
      std::cout << "mpTrackEnd()" << std::endl;
   }

// III.:

   void mpNoteOn( u64 tick, int channel, int midiNote, int velocity ) override
   {
      std::cout << "mpNoteOn("<<tick<<","<<channel<<","<<midiNote<<","<<velocity<<")" << std::endl;
   }
   void mpNoteOff( u64 tick, int channel, int midiNote, int velocity ) override
   {
      std::cout << "mpNoteOff("<<tick<<","<<channel<<","<<midiNote<<","<<velocity<<")" << std::endl;
   }
   void mpPolyphonicAftertouch( u64 tick, int value ) override
   {
      std::cout << "mpPolyphonicAftertouch("<<tick<<","<<value<<")" << std::endl;
   }
   void mpChannelAftertouch( u64 tick, int channel, int value ) override
   {
      std::cout << "mpChannelAftertouch("<<tick<<","<<channel<<","<<value<<")" << std::endl;
   }
   void mpPitchBend( u64 tick, int channel, int value ) override
   {
      std::cout << "mpPitchBend("<<tick<<","<<channel<<","<<value<<")" << std::endl;
   }
   void mpModWheel( u64 tick, int channel, int value ) override
   {
      std::cout << "mpModWheel("<<tick<<","<<channel<<","<<value<<")" << std::endl;
   }
   void mpControlChange( u64 tick, int channel, int cc, int value ) override
   {
      std::cout << "mpControlChange("<<tick<<","<<channel<<","<<cc<<","<<value<<")" << std::endl;
   }
   void mpProgramChange( u64 tick, int channel, int program ) override
   {
      std::cout << "mpProgramChange("<<tick<<","<<channel<<","<<program<<")" << std::endl;
   }
   void mpSetTempo( u64 tick, float bpm, int microsecondsPerTick ) override
   {
      std::cout << "mpTempoBPM("<<tick<<","<<bpm<<"bpm,"<<microsecondsPerTick<<"ys)" << std::endl;
   }
   void mpSMPTEOffset( u64 tick, int hh, int mm, int ss, int fc, int sf ) override
   {
      std::cout << "mpSMPTEOffset("<<tick<<","<<hh<<":"<<mm<<":"<<ss
                                   <<" "<<fc<<","<<sf<<")" << std::endl;
   }
   void mpTimeSignature( u64 tick, int top, int bottom, int clocksPerBeat, int n32rd_per_beat ) override
   {
      std::cout << "mpTimeSignature("<<tick<<","<<top<<","<<bottom<<","
                                     <<clocksPerBeat<<","<<n32rd_per_beat<<")" << std::endl;
   }
   void mpKeySignature( u64 tick, int tonart_c_offset, int minor ) override
   {
      std::cout << "mpKeySignature("<<tick<<", tonart_c_offset = "<<tonart_c_offset<<", "
                                   "minor = "<<minor<<")" << std::endl;
   }
   void mpSequenceNumber( u64 tick, int sequenceNumber ) override
   {
      std::cout << "mpSequenceNumber(" <<tick<<","<< sequenceNumber << ")" << std::endl;
   }
   void mpChannelPrefix( u64 tick, int channelPrefix ) override
   {
      std::cout << "mpChannelPrefix("<<tick<<","<<channelPrefix<<")" << std::endl;
   }
   void mpPortDisplay( u64 tick, int port ) override
   {
      std::cout << "mpPortDisplay("<<tick<<","<<port<<")" << std::endl;
   }
   void mpMetaText( u64 tick, STR const & metaText ) override
   {
      std::cout << "mpMetaText("<<tick<<","<<metaText<<")" << std::endl;
   }
   void mpMetaCopyright( u64 tick, STR const & metaText ) override
   {
      std::cout << "mpMetaCopyright("<<tick<<","<<metaText<<")" << std::endl;
   }
   void mpMetaTrackName( u64 tick, STR const & metaText ) override
   {
      std::cout << "mpMetaTrackName("<<tick<<","<<metaText<<")" << std::endl;
   }
   void mpMetaInstrumentName( u64 tick, STR const & metaText ) override
   {
      std::cout << "mpMetaInstrumentName("<<tick<<","<<metaText<<")" << std::endl;
   }
   void mpMetaLyric( u64 tick, STR const & metaText ) override
   {
      std::cout << "mpMetaLyric("<<tick<<","<<metaText<<")" << std::endl;
   }
   void mpMetaMarker( u64 tick, STR const & metaText ) override
   {
      std::cout << "mpMetaMarker("<<tick<<","<<metaText<<")" << std::endl;
   }
   void mpMetaCuePoint( u64 tick, STR const & metaText ) override
   {
      std::cout << "mpMetaCuePoint("<<tick<<","<<metaText<<")" << std::endl;
   }
   void mpMetaProgramName( u64 tick, STR const & metaText ) override
   {
      std::cout << "mpMetaProgramName("<<tick<<","<<metaText<<")" << std::endl;
   }
   void mpMetaDeviceName( u64 tick, STR const & metaText ) override
   {
      std::cout << "mpMetaDeviceName("<<tick<<","<<metaText<<")" << std::endl;
   }
};

} // end namespace de


