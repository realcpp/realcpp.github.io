#pragma once
#include "MidiFile.hpp"
#include <DarkImage.hpp>

// These structs form a sheet of music
// They are kinda equivalent to MIDI track, channel and file.
// But they are not equal and are separated.

// The listener has its own structs to decode MIDI into Notenblatt/SheetMusic
// Especially the MIDI time encoding is completly resolved into absolute timestamps
//

namespace de {

// =====================================================================================
struct HtmlConverterUtil
// =====================================================================================
{
   DE_CREATE_LOGGER("HtmlConverterUtil")

   static std::string
   getNoteName( int midiNote, bool printOctave = true )
   {
      return MidiUtil::getNoteStr( midiNote, printOctave );
   }

   static Image
   createPitchBendImage( MidiFile const & file, MidiController const & cc );

   static Image
   createNoteImage( MidiFile const & file, int track, int channel );

   static Image
   createCCImage( MidiFile const & file, MidiController const & cc );

   static Image
   createCCImage( MidiFile const & file, int trackIndex, int channelIndex, int ccIndex );

};

} // end namespace de
