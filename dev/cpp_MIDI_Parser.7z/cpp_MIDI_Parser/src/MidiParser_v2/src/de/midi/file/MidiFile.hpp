#pragma once
#include "MidiUtil.hpp"

namespace de {

// =======================================================================
template< typename T > struct Range
// =======================================================================
{
   T min = std::numeric_limits< T >::max();
   T max = std::numeric_limits< T >::lowest();

   T getRange() const { return max - min; }

   std::string
   str() const
   {
      std::ostringstream o;
      o << min << "," << max;
      return o.str();
   }
};

// For all meta text events
// =======================================================================
struct MidiMetaEvent
// =======================================================================
{
   u64 m_tick;
   s32 m_meta;   // metaType
   STR m_text;

   MidiMetaEvent()
      : m_tick(0), m_meta(-1)
   {

   }

   STR
   toString() const
   {
      std::ostringstream o;
      o << "tick(" << m_tick << "), metaType(" << m_meta << "), text(" << m_text << ")";
      return o.str();
   }

};

/*
// =======================================================================
struct MidiTimedValue
// =======================================================================
{
   s32 m_cc;
   u64 m_tick;
   f32 m_value;     // tempo in beats per minute

   MidiTimedValue() : m_cc(-1), m_tick(0), m_value(0.f)
   {

   }

   STR
   toString() const
   {
      std::ostringstream o;
      o << "cc(" << m_cc << "), tick(" << m_tick << "), value(" << m_value << ")";
      return o.str();
   }
};

// =======================================================================
struct MidiTempo // is also a MidiTimedValue
// =======================================================================
{
   u64 m_tick;  // time im ms
   f32 m_tempo; // tempo in beats per minute

   MidiTempo() : m_tick(0), m_tempo(0)
   {}

   STR
   toString() const
   {
      std::ostringstream o;
      o << "tick(" << m_tick << "), tempo(" << m_tempo << ")";
      return o.str();
   }
};
*/
// =======================================================================
struct MidiSetTempoEvent
// =======================================================================
{
   u64 m_tick;
   s64 m_duration; // in raw ticks
   int m_microsecondsPerQuarterNote;

   MidiSetTempoEvent()
      : m_tick(0)
      , m_duration(-1)
      , m_microsecondsPerQuarterNote(-1)
   {}

   static MidiSetTempoEvent
   fromBPM( u64 tick, double bpm )
   {
      MidiSetTempoEvent e;
      e.m_tick = tick;
      e.m_microsecondsPerQuarterNote = int( std::round( double(60000000.0) / bpm ) );
      return e;
   }

   bool
   isValid() const
   {
      return m_microsecondsPerQuarterNote > 0;
   }

   double
   computeBPM() const
   {
      if ( !isValid() ) return 0.0;
      return double(60000000.0) / double(m_microsecondsPerQuarterNote);
   }

   double
   computeDurationInSeconds( int ticksPerQuarterNote ) const
   {
      if ( ticksPerQuarterNote < 1 ) return 0.0;
      if ( m_microsecondsPerQuarterNote < 1 ) return 0.0;
      if ( m_duration < 1 ) return 0.0;
      f64 secondsPerTick = f64(m_microsecondsPerQuarterNote) /(1000000.0 * ticksPerQuarterNote);
      f64 elapsedSeconds = f64(m_duration) * secondsPerTick;
      return elapsedSeconds;
   }

   STR
   toString() const
   {
      std::ostringstream o; o <<
      "tick(" << m_tick << "), "
      "duration("<<m_duration<<"), "
      "bpm(" << computeBPM() << "), "
      "microsecondsPerQuarterNote(" << m_microsecondsPerQuarterNote << ")";
      return o.str();
   }
};

// =======================================================================
struct MidiTimeSignatureEvent
// =======================================================================
{
   u64 m_tick;
   int m_top;
   int m_bottom;
   int m_clocksPerBeat;
   int m_n32rdPerBar;

   MidiTimeSignatureEvent()
      : m_tick(0)
      , m_top(-1)
      , m_bottom(-1)
      , m_clocksPerBeat(-1)
      , m_n32rdPerBar(-1)
   {}

   void set( int top, int bottom, int clocksPerBeat, int n32rd_per_bar )
   {
      m_top = top;
      m_bottom = bottom;
      m_clocksPerBeat = clocksPerBeat;
      m_n32rdPerBar = n32rd_per_bar;
   }

   bool
   isValid() const
   {
      if (m_top < 1) return false;
      if (m_bottom < 1) return false;
      if (m_clocksPerBeat < 1) return false;
      if (m_n32rdPerBar < 1) return false;
      return true;
   }

   STR
   toString() const
   {
      std::ostringstream o; o <<
      "tick(" << m_tick << "), "
      "takt(" << m_top << "," << m_bottom << "), "
      "clocksPerBeat(" << m_top << "), "
      "num32rdPerBar(" << m_n32rdPerBar << ")";
      return o.str();
   }
};

// =======================================================================
struct MidiKeySignatureEvent
// =======================================================================
{
   u64 m_tick;
   int m_cdur_offset;
   int m_minor;

   MidiKeySignatureEvent()
      : m_tick(0)
      , m_cdur_offset(-127)
      , m_minor(-127)
   {}

   bool
   isValid() const
   {
      if (m_cdur_offset < -7) return false;
      if (m_cdur_offset >  7) return false;
      if (m_minor < -2) return false;
      if (m_minor >  2) return false;
      return true;
   }

   STR
   toString() const
   {
      std::ostringstream o;
      o << "tick(" << m_tick << ")"
         ", C-Dur-offset(" << m_cdur_offset << ")"
         ", minor(" << m_minor << ")";
      return o.str();
   }
};

/*
// =======================================================================
struct MidiTempoMap
// =======================================================================
{
   //DE_CREATE_LOGGER("de.midi.MidiClock")
   u64 m_time;                // in milliseconds from file start 0.
   int m_ticksPerQuarterNote; // this is how the midi clock time deltas are to be interpreted
   int m_top;                 // d.k.
   int m_bottom;              // d.k. beats / bar
   float m_tempo;          // m_beatsPerMinute
   int m_clocksPerBeat = 24;     // bar tempo - clocks per beat
   int m_n32rdPerBar = 8;          // bar tempo - 32nd per bar = 8ths per beat
   int m_microsecondsPerBeat = 646000;    // bar tempo - microseconds per beat



   std::vector< MidiTempo > m_tempoMap;

   //std::string m_debugStr;

   MidiTempoMap()
      : m_time(0)
      , m_ticksPerQuarterNote(-1) // Given by midi header
      , m_top(-1)                  // Given by midi event mpTimeSignature
      , m_bottom(-1)               // Given by midi event mpTimeSignature
      , m_tempo(-1)               // Given by midi event mpTempoBPM( beatsPerMinute )
   {}

   u64 getTime() const { return m_time; }

   void onHeader( int fileType, int trackCount, int ticksPerQuarterNote )
   {
      (void)fileType;
      (void)trackCount;
      m_ticksPerQuarterNote = ticksPerQuarterNote;
   }

   void onSetTempo( u64 tick, float bpm )
   {
      // New tempoMap entry if current tempo differs from given tempo in bpm.
      if ( std::abs( m_tempo - bpm ) < 0.0001f  )
      {
         m_tempoMap.emplace_back();
         auto & tempo = m_tempoMap.back();
         tempo.m_tick = tick;
         tempo.m_tempo = bpm;
      }
      m_tempo = bpm;

      //   std::ostringstream o;
      //   o << "Tempo("<<pts<<","<<bpm<<", m_tempoMap = "<<m_tempoMap.size()<<"\n";
      //   emitDebugMessage( o.str() );
   }

   void onSMPTEOffset( int hh, int mm, int ss, int fc, int sf )
   {
      //   std::ostringstream o;
      //   o << "SMPTE("<<pts<<","<<hh<<","<<mm<<","<<ss<<","<<fc<<","<<sf<<")\n";
      //   emitDebugMessage( o.str() );
   }

   void onTimeSignature( int top, int bottom, int clocksPerBeat, int n32rd_per_bar )
   {
      m_top = top;
      m_bottom = bottom;
      m_clocksPerBeat = clocksPerBeat;
      m_n32rdPerBar = n32rd_per_bar;

      //   std::ostringstream o;
      //   o << "TimeSignature("<<pts<<","<<top<<"/"<<bottom<<","<<clocksPerBeat<<"cpb,"<<n32rd_per_bar<<")\n";
      //   emitDebugMessage( o.str() );
   }

   void update()
   {
      //double elapsedBeats = double( delta_ticks ) / double(m_ticksPerQuarterNote);
      //m_time += elapsedBeats;
   }

   void reset()
   {
      m_time = 0;
   }

   void tick( int delta_ticks ) // delta_ticks
   {
      u64 currentTime = m_time;

      f64 elapsedBeats = f64( delta_ticks ) / f64(m_ticksPerQuarterNote);

      u64 elapsedTimeMs = u64( elapsedBeats * f64(m_tempo) * 60000.0 );

      m_time += elapsedTimeMs;

      //   std::ostringstream o;
      //   o << "Tick("<<delta_ticks<<"[ticks],"<<m_tempo<<"[bpm]) = "
      //      <<elapsedTimeMs<<"[ms], currentTime = "<<currentTime<<"[ms].\n";
      //   emitDebugMessage( o.str() );
   }

};
*/

// =======================================================================
struct MidiNote
// =======================================================================
{
   int m_channel;
   int m_midiNote;
   int m_attack;
   u64 m_attackMs;
   int m_release;
   u64 m_releaseMs;

   MidiNote()
      : m_channel(0), m_midiNote(0)
      , m_attack(0), m_attackMs(0)
      , m_release(0), m_releaseMs(0)
   {}

   MidiNote(int channel, int midiNote,
            int attack, u64 attackMs,
            int release, u64 releaseMs)
      : m_channel(0), m_midiNote(midiNote)
      , m_attack(attack), m_attackMs(attackMs)
      , m_release(release), m_releaseMs(releaseMs)
   {}

   u64
   duration() const { return m_releaseMs - m_attackMs; }

   STR
   toString() const
   {
      std::ostringstream o; o <<
      "channel(" << m_channel << "), "
      "midiNote(" << m_midiNote << "), "
      "velocity(" << m_attack << "," << m_release << "), "
      "duration(" << m_attackMs << "," << m_releaseMs << ")";
      return o.str();
   }
};


// =======================================================================
struct MidiControllerEvent
// =======================================================================
{
   u64 m_tick;
   s32 m_cc;
   s32 m_value;

   MidiControllerEvent() : m_tick(0), m_cc(-1), m_value(0.f)
   {

   }

   STR
   toString() const
   {
      std::ostringstream o;
      o << "tick(" << m_tick << "), cc(" << m_cc << "), value(" << m_value << ")";
      return o.str();
   }
};

// =======================================================================
struct MidiController
// =======================================================================
{
   int m_cc;

   std::vector< MidiControllerEvent > m_events;

   explicit MidiController( int cc = -1 ) : m_cc(cc)
   {}

   MidiControllerEvent*
   addEvent( MidiControllerEvent const & mce )
   {
      m_events.emplace_back( mce );
      return &m_events.back();
   }

   STR
   toString() const
   {
      std::ostringstream o;
      o << "cc(" << m_cc << "), events(" << m_events.size() << ")";
      return o.str();
   }

   Range<int> getValueRange() const
   {
      Range<int> range;
      for ( size_t i = 0; i < m_events.size(); ++i )
      {
         MidiControllerEvent const & e = m_events[ i ];
         int const value = e.m_value;
         range.min = std::min( value, range.min );
         range.max = std::max( value, range.max );
      }
      return range;
   }

   Range<uint64_t> getTickRange() const
   {
      Range<uint64_t> range;
      for ( size_t i = 0; i < m_events.size(); ++i )
      {
         MidiControllerEvent const & e = m_events[ i ];
         uint64_t const tick = e.m_tick;
         range.min = std::min( tick, range.min );
         range.max = std::max( tick, range.max );
      }
      return range;
   }
};

/*
   void mpProgramChange( u64 tick, int channel, int program ) override
   {
      auto channelPtr = m_track.getChannel(channel);
      if ( !channelPtr )
      {
         std::runtime_error("No Channel");
      }
      (void)tick;
      channelPtr->m_instrument = program;
   }
   void mpControlChange( u64 tick, int channel, int cc, int value ) override
   {
      (void)tick;
      (void)cc;
      (void)value;

      auto channelPtr = m_track.getChannel(channel);
      if ( !channelPtr )
      {
         std::runtime_error("No Channel");
      }
      (void)tick;
      MidiTimedValue mtv;
      mtv.m_cc = cc;
      mtv.m_tick = tick;
      mtv.m_value = float(value) / 16384.0f;
      channelPtr->getController(cc).m_curve.emplace_back( mtv );
   }
   void mpPolyphonicAftertouch( u64 tick, int value ) override
   {
      (void)tick;
      (void)value;
   }
   void mpChannelAftertouch( u64 tick, int channel, int value ) override
   {
      (void)tick;
      (void)value;
   }
   void mpPitchBend( u64 tick, int channel, int value ) override
   {
      (void)tick;
      (void)value;
   }
   void mpModWheel( u64 tick, int channel, int value ) override
   */

// =======================================================================
struct MidiChannel
// =======================================================================
{
   int m_channelIndex;  // 0...15, 9 = always drums
   int m_instrument;    // GM instrument or drum number

   std::vector< MidiNote > m_notes;

   std::vector< MidiController > m_controller;

   MidiController m_channelAftertouch;
   MidiController m_pitchBend;

   explicit MidiChannel( int channelIndex = -1 )
      : m_channelIndex(channelIndex)
      , m_instrument(-1)
   {}

   MidiNote*
   addNote( MidiNote const & note )
   {
      m_notes.emplace_back( note );
      return &m_notes.back();
   }

   MidiNote*
   addNote( int channel, int midiNote,
            int attack, uint32_t attackMs,
            int release, uint32_t releaseMs)
   {
      MidiNote note;
      note.m_channel = channel;
      note.m_midiNote = midiNote;
      note.m_attack = attack;
      note.m_attackMs = attackMs;
      note.m_release = release;
      note.m_releaseMs = releaseMs;
      return addNote( note );
   }

   MidiNote*
   getLastNote( int midiNote )
   {
      auto it = std::find_if( m_notes.rbegin(), m_notes.rend(),
         [&]( MidiNote const & cached ) { return cached.m_midiNote == midiNote; });
      if ( it == m_notes.rend() )
      {
         //DE_ERROR("No midi note (",midiNote,") found in track(", m_trackIndex,")")
         return nullptr;
      }

      //size_t index = std::distance( m_noten.rend(), it );
      return &(*it);
   }

   MidiController &
   getController( int cc ) // We guarantee that the controller exists.
   {
      auto it = std::find_if( m_controller.begin(), m_controller.end(),
         [&]( MidiController const & cached ) { return cached.m_cc == cc; });
      if ( it == m_controller.end() )
      {
         m_controller.emplace_back( cc ); // Value ctr
         return m_controller.back();
      }
      else
      {
         return (*it);
      }
   }

   STR
   toString( bool withNotes = false ) const
   {
      std::ostringstream o;
      //if ( !m_touched ) o << "UNTOUCHED ";
      o << "Channel["<<m_channelIndex<<"] "
            "instrument(" << GM_toString( m_instrument ) << "), "
            "controller(" << m_controller.size() << "), "
            //"lyrics(" << m_lyrics << ")"
            "notes(" << m_notes.size() << ")\n";
      if (withNotes)
      {
         for ( size_t i = 0; i < m_notes.size(); ++i )
         {
            o <<"Channel["<<m_channelIndex<<"].Note["<<i<<"] " << m_notes[i].toString() << "\n";
         }
      }
      return o.str();
   }

   Range<int> getNoteRange() const
   {
      Range<int> range;
      for ( size_t i = 0; i < m_notes.size(); ++i )
      {
         auto const & note = m_notes[ i ];
         int midiNote = note.m_midiNote;
         range.min = std::min( midiNote, range.min );
         range.max = std::max( midiNote, range.max );
      }
      return range;
   }

   Range<uint64_t> getTickRange() const
   {
      Range<uint64_t> range;
      for ( size_t i = 0; i < m_notes.size(); ++i )
      {
         auto const & note = m_notes[ i ];
         uint64_t tickStart = note.m_attackMs;
         uint64_t tickEnd = note.m_releaseMs;
         range.min = std::min( tickStart, range.min );
         range.max = std::max( tickStart, range.max );
         range.min = std::min( tickEnd, range.min );
         range.max = std::max( tickEnd, range.max );
      }
      return range;
   }

};

// Midi can have u16 (65536) tracks with each 16 channels. Channel 9 is reserved for drums.
// That should be enough for any composer.
// =======================================================================
struct MidiTrack
// =======================================================================
{
   int m_trackIndex;
   std::string m_trackName;  // trackName given by meta events

   std::vector< MidiChannel > m_channels;

   std::vector< MidiSetTempoEvent > m_setTempoEvents;
   std::vector< MidiTimeSignatureEvent > m_timeSignatureEvents;
   std::vector< MidiKeySignatureEvent > m_keySignatureEvents;

   MidiController m_polyphonicAftertouch;

   std::vector< MidiMetaEvent > m_textEvents;
   std::vector< MidiMetaEvent > m_lyricEvents;

   explicit MidiTrack( int trackIndex = -1 )
      : m_trackIndex(trackIndex)
   {}

   ~MidiTrack()
   {
   }

   MidiChannel &
   getChannel( int channel ) // We guarantee the channel exist or exit program immediatly.
   {
      if ( channel < 0 || channel > 15 )
      {
         throw std::runtime_error("Invalid channel");
      }

      auto it = std::find_if( m_channels.begin(), m_channels.end(),
                              [&]( MidiChannel const & cached )
                              {
                                 return cached.m_channelIndex == channel;
                              });

      if ( it == m_channels.end() )
      {
         m_channels.emplace_back( channel );
         return m_channels.back();
      }
      else
      {
         return (*it);
      }
   }

   std::string
   toString( bool withNotes ) const
   {
      std::ostringstream o;
      //if ( !m_touched ) o << "UNTOUCHED ";
      o << "Track["<<m_trackIndex<<"] (" << m_trackName << ") "
            "channels(" << m_channels.size() << ")\n";
      if (withNotes)
      {
         for ( size_t i = 0; i < m_channels.size(); ++i )
         {
            o << "Track["<<m_trackIndex<<"].Channel["<<i<<"] " << m_channels[i].toString() << "\n";
         }
      }
      return o.str();
   }

};

// =======================================================================
struct MidiFile
// =======================================================================
{
   std::string m_fileName;
   // <header>
   int m_fileType;
   int m_trackCount;
   int m_ticksPerQuarterNote;
   // </header>

   std::vector< MidiTrack > m_tracks;  // Up to 65536 tracks possible ( more than enough )

   MidiFile()
      : m_fileType(-1)
      , m_trackCount(-1)
      , m_ticksPerQuarterNote(-1)
   {}

   void
   reset()
   {
      m_fileName = "";
      m_fileType = -1;
      m_trackCount = -1;
      m_ticksPerQuarterNote = -1;
      m_tracks.clear();
   }

   MidiTrack*
   addTrack( MidiTrack const & track )
   {
      m_tracks.emplace_back( track );
      return &m_tracks.back();
   }

   MidiTrack &
   getTrack( int trackIndex ) // We guarantee the track exist -> returns reference, not pointer.
   {
      auto it = std::find_if( m_tracks.begin(), m_tracks.end(),
                        [&]( MidiTrack const & cached )
                        {
                           return cached.m_trackIndex == trackIndex;
                        });

      if ( it == m_tracks.end() )
      {
         m_tracks.emplace_back( trackIndex ); // Value ctr
         return m_tracks.back();
      }
      else
      {
         return (*it);
      }
   }

   std::string
   toString() const
   {
      std::ostringstream o;
      o << "FileName = "<<m_fileName<<"\n";
      o << "FileType = "<<m_fileType<<"\n";
      o << "TicksPerQuarterNote = "<<m_ticksPerQuarterNote<<"\n";
      o << "TrackCount = "<<m_tracks.size()<<" ("<<m_trackCount<<")\n";
      for ( MidiTrack const & track : m_tracks )
      {
         o << track.toString( true );
      }
      return o.str();
   }
};

} // end namespace de
