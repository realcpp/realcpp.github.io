#include "HtmlConverterUtil.hpp"

namespace de {

// static
Image
HtmlConverterUtil::createPitchBendImage( MidiFile const & file, MidiController const & cc )
{
   //auto const valueRange = cc.getValueRange();
   auto const tickRange = cc.getTickRange();

   Font5x8 fontSmall(1,1,0,0,1,1);
   Font5x8 fontMedium(2,2,0,0,1,1);
   Font5x8 fontBig(4,4,1,1,2,2);

   f64 nQuarterNotes = f64(tickRange.max) / f64(file.m_ticksPerQuarterNote);

   int w_start = 32;
   int w_per_quarter = 32; // 8th = 16px, 16th = 8px, 32th = 4px;
   int w_content = int(w_per_quarter * nQuarterNotes);

   Image img(w_start + w_content + 10, 128 + 20);
   img.fill(0xFFDDFFFF);

   // Draw content rect
   Recti r_content( w_start, 10, img.w() - w_start - 10, img.h() - 20 );
   ImagePainter::drawRectBorder( img, r_content, 0xFF808080 );

   // Draw bars
   for ( int i = w_start; i < img.w()-10; i += w_per_quarter * 4 )
   {
      ImagePainter::drawLine( img, i, 10, i, img.h() - 1 - 10, 0xFF808080 );
   }

   // Draw controller events
   MidiControllerEvent def;
   def.m_tick = 0;
   def.m_value = (16384 / 2) - 1;
   for ( size_t i = 0; i < cc.m_events.size(); i++ )
   {
      MidiControllerEvent const & e1 = (i==0) ? def : cc.m_events[ i-1 ];
      MidiControllerEvent const & e2 = cc.m_events[ i ];
      int x1 = w_start + int(f64(r_content.w()) * f64(e1.m_tick) / f64(tickRange.max) );
      int x2 = w_start + int(f64(r_content.w()) * f64(e2.m_tick) / f64(tickRange.max) );
      int y1 = img.h() - 1 - 10 - int(f64(e1.m_value) * 127.0/16383.0);
      int y2 = img.h() - 1 - 10 - int(f64(e2.m_value) * 127.0/16383.0);
      ImagePainter::drawLine( img, x1, y1, x2, y2, 0xFF4040FF );
   }

   return img;
}

// static
Image
HtmlConverterUtil::createCCImage( MidiFile const & file, MidiController const & cc )
{
   //auto const valueRange = cc.getValueRange();
   auto const tickRange = cc.getTickRange();

   Font5x8 fontSmall(1,1,0,0,1,1);
   Font5x8 fontMedium(2,2,0,0,1,1);
   Font5x8 fontBig(4,4,1,1,2,2);

   f64 nQuarterNotes = f64(tickRange.max) / f64(file.m_ticksPerQuarterNote);

   int w_start = 32;
   int w_per_quarter = 32; // 8th = 16px, 16th = 8px, 32th = 4px;
   int w_content = int(w_per_quarter * nQuarterNotes);

   Image img(w_start + w_content + 10, 128 + 20);
   img.fill(0xFFDDFFFF);

   // Draw content rect
   Recti r_content( w_start, 10, img.w() - w_start - 10, img.h() - 20 );
   ImagePainter::drawRectBorder( img, r_content, 0xFF808080 );

   // Draw bars
   for ( int i = w_start; i < img.w()-10; i += w_per_quarter * 4 )
   {
      ImagePainter::drawLine( img, i, 10, i, img.h() - 1 - 10, 0xFF808080 );
   }

   // Draw controller events
   MidiControllerEvent def;
   def.m_tick = 0;
   def.m_value = 0;
   if ( cc.m_cc == CC_7_Volume )
   {
      def.m_value = 127;
   }

   for ( size_t i = 0; i < cc.m_events.size(); i++ )
   {
      MidiControllerEvent const & e1 = (i==0) ? def : cc.m_events[ i-1 ];
      MidiControllerEvent const & e2 = cc.m_events[ i ];
      int x1 = w_start + int(f64(r_content.w()) * f64(e1.m_tick) / f64(tickRange.max) );
      int x2 = w_start + int(f64(r_content.w()) * f64(e2.m_tick) / f64(tickRange.max) );
      int y1 = img.h() - 1 - 10 - e1.m_value;
      int y2 = img.h() - 1 - 10 - e2.m_value;
      ImagePainter::drawLine( img, x1, y1, x2, y2, 0xFF4040FF );
   }

   return img;
}

// static
Image
HtmlConverterUtil::createCCImage( MidiFile const & file, int trackIndex, int channelIndex, int ccIndex )
{
   MidiTrack const & track = file.m_tracks[ trackIndex ];
   MidiChannel const & channel = track.m_channels[ channelIndex ];
   MidiController const & cc = channel.m_controller[ ccIndex ];
   return createCCImage( file, cc );
}

// static
Image
HtmlConverterUtil::createNoteImage( MidiFile const & file, int trackIndex, int channelIndex )
{
   MidiTrack const & track = file.m_tracks[ trackIndex ];
   MidiChannel const & channel = track.m_channels[ channelIndex ];
   auto const noteRange = channel.getNoteRange(); // y
   auto const tickRange = channel.getTickRange(); // x=t

   Font5x8 fontSmall(1,1,0,0,1,1);
   Font5x8 fontMedium(2,2,0,0,1,1);
   Font5x8 fontBig(4,4,1,1,2,2);

   int lineHeight = 11;

   f64 nQuarterNotes = f64(tickRange.max) / f64(file.m_ticksPerQuarterNote);

   int w_keyboard = 32;
   int w_per_quarter = 32; // 8th = 16px, 16th = 8px, 32th = 4px;
   int w_notes = int(w_per_quarter * nQuarterNotes);
   int h_notes = lineHeight * int(noteRange.getRange() + 3);

   Image img(w_notes + w_keyboard,h_notes);
   img.fill(0xFFDDFFFF);

   // Draw keyboard background
   for ( int i = 0; i <= noteRange.getRange(); i++ )
   {
      int midiNote = noteRange.min + i;
      bool isBlackKey = MidiUtil::isBlackPianoKey(midiNote);
      int y = img.h() - 1 - 2*lineHeight - (midiNote - noteRange.min) * lineHeight;
      Recti r_note(0,y,img.w(),lineHeight);
      ImagePainter::drawRect( img, r_note, isBlackKey ? 0xFFAAAAAA : 0xFFEEEEEE );
      ImagePainter::drawRectBorder( img, r_note, 0xFF888888 );
   }

   // Draw keyboard foreground
   for ( int i = 0; i <= noteRange.getRange(); i++ )
   {
      int midiNote = noteRange.min + i;
      int y = img.h() - 1 - 2*lineHeight - (midiNote - noteRange.min) * lineHeight;
      Recti r_note(0,y,32,lineHeight);

      ImagePainter::drawText5x8( img, r_note.centerX() + 1, r_note.centerY() + 1,
                        std::to_string(midiNote), 0xFF000000, fontSmall, Align::Centered );
   }

   // Draw bars
   for ( int i = w_keyboard; i < img.w(); i += w_per_quarter * 4 )
   {
      ImagePainter::drawLine( img, i, lineHeight, i, img.h() - 1 - lineHeight, 0xFF808080 );
   }

   // Draw notes
   for ( size_t i = 0; i < channel.m_notes.size(); ++i )
   {
      MidiNote const & note = channel.m_notes[ i ];
      STR noteName = MidiUtil::getNoteStr(note.m_midiNote, false);
      u32 noteColor = MidiUtil::getNoteColor(note.m_midiNote);
      bool isBlack = MidiUtil::isBlackPianoKey(note.m_midiNote);

      int x = w_keyboard + int(f64(w_notes) * f64(note.m_attackMs) / f64(tickRange.max) );
      int w = int(f64(w_notes) * f64(note.m_releaseMs - note.m_attackMs) / f64(tickRange.max) );

      int y = img.h() - 1 - 2*lineHeight - (note.m_midiNote - noteRange.min) * lineHeight;
      int h = lineHeight;

      Recti r_note(x,y,w,h);
      if ( r_note.w() < 8 ) r_note.setWidth(8);
      ImagePainter::drawRect( img, r_note, noteColor );
      ImagePainter::drawRectBorder( img, r_note, isBlack ? 0xFFFFFFFF : 0xFF000000 );

      int cx = r_note.centerX() + 1;
      int cy = r_note.centerY() + 1;

      ImagePainter::drawText5x8( img, cx,cy, noteName, 0xFF000000, fontSmall, Align::Centered );
   }

   return img;
}

/*
// static
Image
HtmlUtil::createTrackImage( MidiFile const & file, int trackIndex, int w_per_bar, int h )
{
   Font5x8 fontSmall(1,1,0,0,1,1);
   Font5x8 fontMedium(2,2,0,0,1,1);
   Font5x8 fontBig(4,4,1,1,2,2);

   int lineHeight = 11;
   int trackCount = int( file.m_tracks.size() );
   int ticksPerQuarterNote = file.m_ticksPerQuarterNote;
   int top = file.m_top;
   int bottom = file.m_bottom;
   SheetTrack const & track = sheet.getTrack( trackIndex );
   auto const & notes = track.m_notes;
   auto const noteRange = file.getNoteRange(); // y
   auto const tickRange = file.getTickRange(); // x=t

   DE_DEBUG("Noten.Count = ", notes.size() )

   int w = w_per_bar;

   if ( notes.size() > 0 )
   {
      SheetNote const lastNote = notes.back();
      double numQuarterNotes = double( lastNote.m_releaseMs ) /
                               double( ticksPerQuarterNote );
      double numBars = numQuarterNotes / double( bottom );
      w = int( double( w_per_bar ) * numBars );

      DE_DEBUG("TicksPerQuarterNote = ", ticksPerQuarterNote )
      DE_DEBUG("LastNote.m_releaseMs = ", lastNote.m_releaseMs )
      DE_DEBUG("numQuarterNotes = ", numQuarterNotes )
      DE_DEBUG("numBars = ", numBars )
   }

   DE_DEBUG("Image.Width = ", w )
   DE_DEBUG("Image.Height = ", h )

   Image img( w, h );
   img.fill(0xFFFFFFFF);


   std::ostringstream o;
   o << "Track Nr."<< (trackIndex+1) << "/" << trackCount <<
        ", Name(" << track.m_trackName << ")"
        ", Tempo(" << sheet.m_tempo << ")"
        ", Duration(" << sheet.m_tempo << ")"
        ", NoteCount(" << notes.size() << ")"
        ", NoteRange(" << noteRange.str() << ")"
        ", TickRange(" << tickRange.str() << ")";

   ImagePainter::drawText5x8( img, 5,1, o.str(), 0xFF000000, fontSmall );

   o.str("");
   o << midi::EMidiGM_toString( track.m_instrument );
   ImagePainter::drawText5x8( img, 5,15, o.str(), 0xFF000000, fontSmall );

   o.str(""); o << top;
   ImagePainter::drawText5x8( img, 25,30, o.str(), 0xFF000000, fontMedium );

   o.str(""); o << bottom;
   ImagePainter::drawText5x8( img, 25,50, o.str(), 0xFF000000, fontMedium );

   double ft = 0.01 * double( img.w() ) / double( sheet.m_ticksPerQuarterNote );

   for ( size_t i = 0; i < notes.size(); ++i )
   {
      SheetNote const & note = notes[i];

      double t1 = ft * double( note.m_attackMs );
      double t2 = ft * double( note.m_releaseMs );

      int x1 = 100 + int( std::round( t1 ) );
      int x2 = 100 + int( std::round( t2 ) );

      int y = h-1 - 120- ((note.m_midiNote - 60 ) * (lineHeight)/2);

      uint32_t bgColor = getNoteColor( note.m_midiNote );
      //uint32_t bgColor = fgColor;
      //RGBA_setA(bgColor,127)

      ImagePainter::drawRect( img, Recti(x1,y,x2-x1,lineHeight+1 ), bgColor, true );
      ImagePainter::drawLine( img, x1, y, x1, y+lineHeight, 0xFF000000 );
      ImagePainter::drawLine( img, x2, y, x2, y+lineHeight, 0xFF000000 );
      ImagePainter::drawLine( img, x1, y+lineHeight/2, x2, y+lineHeight/2, 0xFF000000 );


      std::string noteName = getNoteName(note.m_midiNote);
      auto ts = fontSmall.getTextSize(noteName);

      int cx = x1 + ((x2-x1)/2);
      int tx = cx - ts.width/2;
      int ty = y+2;

      ImagePainter::drawText5x8( img, tx,ty, noteName, 0xFF000000, fontSmall );

   }

   int b = 25;
   ImagePainter::drawLine( img, 0, b, w, b, 0xFF000000 ); b += lineHeight;
   ImagePainter::drawLine( img, 0, b, w, b, 0xFF000000 ); b += lineHeight;
   ImagePainter::drawLine( img, 0, b, w, b, 0xFF000000 ); b += lineHeight;
   ImagePainter::drawLine( img, 0, b, w, b, 0xFF000000 ); b += lineHeight;
   ImagePainter::drawLine( img, 0, b, w, b, 0xFF000000 ); b += lineHeight;
   b += 50;
   ImagePainter::drawLine( img, 0, b, w, b, 0xFF000000 ); b += lineHeight;
   ImagePainter::drawLine( img, 0, b, w, b, 0xFF000000 ); b += lineHeight;
   ImagePainter::drawLine( img, 0, b, w, b, 0xFF000000 ); b += lineHeight;
   ImagePainter::drawLine( img, 0, b, w, b, 0xFF000000 ); b += lineHeight;
   ImagePainter::drawLine( img, 0, b, w, b, 0xFF000000 ); b += lineHeight;

   return img;
}
*/

} // end namespace de
