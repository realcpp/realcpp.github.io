// (c) 2022 by <benjaminhampe@gmx.de>
#pragma once
#include "DurationComputer.hpp"

namespace de {

// =======================================================================
struct DurationComputerTest
// =======================================================================
{
   static void
   test()
   {
      testMidiFile( "../../media/midi/lost_3_34.mid" );
      testMidiFile( "../../media/midi/But not tonight - Depeche Mode_4_14.mid" ); // 4:13
      testMidiFile( "../../media/midi/gigidagostino_illflywithyou_joerock_5_03.mid" ); //
      testMidiFile( "../../media/midi/thank_you_50_12.mid" ); //
      testMidiFile( "../../media/midi/Bitter Sweet Symphony_4_16.mid" ); //
      testMidiFile( "../../media/midi/mmm_3_43.mid" ); //
      testMidiFile( "../../media/midi/porcelain_moby_davebulow_4_07.mid" ); //
      testMidiFile( "../../media/midi/hotelcal_6_37.mid" ); //

   }

   static void
   testMidiFile( std::string loadUri )
   {
      std::cout << "========================================================" << std::endl;
      std::cout << "DurationComputerTest: " << loadUri << std::endl;

      ByteVector bv;

      if ( !MidiUtil::loadByteVector( bv, loadUri ) )
      {
         std::cout << "Error: no loadUri" << std::endl;
         return;
      }

      MidiParser parser;
      DurationComputer listener;
      parser.addListener( &listener );

      size_t expect = bv.size();

      //std::cout << "Expect bytes = " << expect << std::endl;

      size_t result = parser.parse( bv.data(), bv.data() + expect, loadUri );

      //std::cout << "Result bytes = " << result << std::endl;

      listener.computeDurationInSeconds();
   }
};

} // end namespace de


/*
   static void
   test()
   {
      DE_DEBUG("Test")

      Image img;
      img.resize( 600, 600 );
      img.fill( 0xFF202020 );

      ImagePainter::drawCircle( img, Recti(1,1,13,8), 0xFFFF0000 );
      ImagePainter::drawCircleBorder( img, Recti(14,1,13,8), 0xFF00FFFF );

      ImagePainter::drawCircle( img, Recti(1,10,12,6), 0xFFFF00FF );
      ImagePainter::drawCircleBorder( img, Recti(13,10,12,6), 0xFF00FFFF );

      ImagePainter::drawCircle( img, Recti(1,20,11,7), 0xFFFF00FF );
      ImagePainter::drawCircleBorder( img, Recti(12,20,11,7), 0xFF00FFFF );
      dbSaveImage( img, "MidiImageWriter_Ellipse.png");
   }

   void
   save( std::string saveUri, std::string title, std::string mediaDir = "" )
   {
      std::ostringstream o;
      std::ofstream file( saveUri.c_str() );
      if ( file.is_open() )
      {
         std::string htmlStr = o.str();
         file << htmlStr;
         file.close();

         DE_DEBUG("Saved HTML ", saveUri, " with ", htmlStr.size(), " bytes.")
      }
   }

*/
