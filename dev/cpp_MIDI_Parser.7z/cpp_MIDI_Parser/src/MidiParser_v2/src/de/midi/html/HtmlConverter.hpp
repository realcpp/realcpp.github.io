#pragma once
#include "HtmlConverterUtil.hpp"

namespace de {

// =====================================================================================
struct HtmlConverter
// =====================================================================================
{
   DE_CREATE_LOGGER("HtmlConverter")

   static bool
   convert( std::string saveUri, MidiFile const & file );
};

} // end namespace de
