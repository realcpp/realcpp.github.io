// (c) 2022 by <benjaminhampe@gmx.de>
#pragma once
#include "MidiFileListener.hpp"

namespace de {

// =======================================================================
struct MidiFileListenerTest
// =======================================================================
{
   // DE_CREATE_LOGGER("de.MidiFileListenerTest")

   static void
   test()
   {
      testMidiFile( "../../media/midi/lost_3_34.mid", "lost_3_34.mid.txt" );
   }

   static void
   testMidiFile( std::string loadUri, std::string saveUri )
   {
      std::cout << "Test MidiFile: " << loadUri << std::endl;

      MidiFile midiFile;
      if ( parseMidiFile( loadUri, &midiFile ) )
      {
         std::cout << "Parsed MidiFile: " << loadUri << std::endl;
      }
      else
      {
         std::cout << "Cant parse MidiFile: " << loadUri << std::endl;
      }

      STR debugString = midiFile.toString();
      std::cout << "Dumped MidiFile: " << debugString.size() << std::endl;
      //std::cout << debugString << std::endl;

      if ( MidiUtil::saveText( debugString, saveUri ) )
      {
         std::cout << "Wrote MidiFile: " << saveUri << std::endl;
      }
   }

   static bool
   parseMidiFile( std::string loadUri, MidiFile* midiFile )
   {
      ByteVector bv;

      if ( MidiUtil::loadByteVector( bv, loadUri ) )
      {
         std::cout << "Loaded ByteVector: " << loadUri << std::endl;
      }
      else
      {
         std::cout << "Error: no loadUri" << std::endl;
         return false;
      }

      MidiParser parser;
      MidiFileListener listener;
      listener.m_file = midiFile;
      parser.addListener( &listener );

      size_t expect = bv.size();

      std::cout << "Expect bytes = " << expect << std::endl;

      u8 const * beg = bv.data();
      u8 const * end = beg + expect;
      size_t result = parser.parse( beg, end, loadUri );

      std::cout << "Result bytes = " << result << std::endl;

      if ( result == expect )
      {
         std::cout << "File parsed entirely: " << loadUri << std::endl;
      }
      else
      {
         std::cout << "File had parse problem or was malformed, can be an error." << std::endl;
      }

      return true;
   }

};

} // end namespace de


/*
   static void
   test()
   {
      DE_DEBUG("Test")

      Image img;
      img.resize( 600, 600 );
      img.fill( 0xFF202020 );

      ImagePainter::drawCircle( img, Recti(1,1,13,8), 0xFFFF0000 );
      ImagePainter::drawCircleBorder( img, Recti(14,1,13,8), 0xFF00FFFF );

      ImagePainter::drawCircle( img, Recti(1,10,12,6), 0xFFFF00FF );
      ImagePainter::drawCircleBorder( img, Recti(13,10,12,6), 0xFF00FFFF );

      ImagePainter::drawCircle( img, Recti(1,20,11,7), 0xFFFF00FF );
      ImagePainter::drawCircleBorder( img, Recti(12,20,11,7), 0xFF00FFFF );
      dbSaveImage( img, "MidiImageWriter_Ellipse.png");
   }

   void
   save( std::string saveUri, std::string title, std::string mediaDir = "" )
   {
      std::ostringstream o;
      std::ofstream file( saveUri.c_str() );
      if ( file.is_open() )
      {
         std::string htmlStr = o.str();
         file << htmlStr;
         file.close();

         DE_DEBUG("Saved HTML ", saveUri, " with ", htmlStr.size(), " bytes.")
      }
   }

*/
