//////////////////////////////////////////////////////////////////////////////
/// @file main_MidiParser.cpp
/// @author Benjamin Hampe <benjamin.hampe@gmx.de>
//////////////////////////////////////////////////////////////////////////////
#include "MidiParserTest.hpp"
#include "MidiFileListenerTest.hpp"
#include "DurationComputerTest.hpp"
#include "HtmlConverterTest.hpp"
//#include "Notenblatt2ImageTest.hpp"

//========================================================================
int main( int argc, char** argv )
//========================================================================
{
   std::cout << argv[ 0 ] << " by (c) 2022 by <benjaminhampe@gmx.de>\n" << std::endl;

   //de::MidiParserTest::test();
   //de::MidiFileListenerTest::test();
   //de::DurationComputerTest::test();
   //de::HtmlConverterTest::test();
   de::HtmlConverterTest::work();
   // auto sheet1 = de::notenblatt::SheetTest::testSheet1();

   // (c) 2022 by <benjaminhampe@gmx.de>
   // Validate dialog result.
   //auto saveUri = "Notenblatt2ImageTest1.html";
   //de::notenblatt::Notenblatt2ImageTest::convert2ImageHtml( sheet1, saveUri );

   // Open your local html browser
   //std::stringstream ss;
   //ss << "\"" << saveUri << "\"";  // Add Quotation marks for uris with spaces.
   //std::string command = ss.str();
   //std::cout << "Run command " << command << std::endl;
   //system( command.c_str() );

   return 0;
}
