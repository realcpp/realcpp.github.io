#!/bin/bash
PWD="$(pwd)"

echo "PWD = $PWD"
echo "Argv[0] = $0"
echo "Argv[1] = $1"
echo "Argv[2] = $2"

BUILD=$PWD/build/win64_RelWithDebInfo_shared
mkdir -p $BUILD
cd $BUILD
cmake \
   -G "MinGW Makefiles" \
   -DCMAKE_BUILD_TYPE=RelWithDebInfo \
   -DCMAKE_PREFIX_PATH=C:/SDK/Qt5.12.3/5.12.3/mingw73_64/lib/cmake \
   ../../
mingw32-make -j$1