#!/bin/bash
PWD="$(pwd)"

echo "PWD = $PWD"
echo "Argv[0] = $0"
echo "Argv[1] = $1"
echo "Argv[2] = $2"

BUILD=$PWD/build/win64_MinSizeRel_static
mkdir -p $BUILD
cd $BUILD
cmake -G "MinGW Makefiles" -DBUILD_STATIC=1 -DCMAKE_BUILD_TYPE=MinSizeRel ../../
mingw32-make -j$1