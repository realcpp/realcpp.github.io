#!/bin/bash
PWD="$(pwd)"
BUILD=$PWD/build/linux64_shared_MinSizeRel
mkdir -p $BUILD
cd $BUILD
cmake -DCMAKE_BUILD_TYPE=MinSizeRel ../../
make -j8
# make install
