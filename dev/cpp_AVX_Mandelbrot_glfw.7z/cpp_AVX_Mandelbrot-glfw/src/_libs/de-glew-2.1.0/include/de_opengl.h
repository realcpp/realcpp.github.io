/// ==========================================================================
/// @file DarkEngineTypes.hpp
/// @brief Base header used by most other DarkEngine headers
/// @author 2018 Benjamin Hampe <benjaminhampe@gmx.de>
/// @copyright Free open source software
/// ==========================================================================

#pragma once

#ifndef GL_EXT_PROTOTYPES
#define GL_EXT_PROTOTYPES 1
#endif

#include <GL/glew.h>

#ifndef GL_TEXTURE_MAX_ANISOTROPY_EXT
#define GL_TEXTURE_MAX_ANISOTROPY_EXT 0x84FE
#endif

#ifndef GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT
#define GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT 0x84FF
#endif


// glewInit(); // VIP call


// #include <GL/wglew.h>

//GLEWAPI GLenum GLEWAPIENTRY wglewInit ();
//GLEWAPI GLboolean GLEWAPIENTRY wglewIsSupported (const char *name);
//GLEWAPI GLboolean GLEWAPIENTRY wglewGetExtension (const char *name);
