/// ==========================================================================
/// @author 2023 Benjamin Hampe <benjaminhampe@gmx.de>
/// ==========================================================================
#pragma once
#include <de_opengl.h>
#include <GL/wglew.h>

//GLEWAPI GLenum GLEWAPIENTRY wglewInit ();
//GLEWAPI GLboolean GLEWAPIENTRY wglewIsSupported (const char *name);
//GLEWAPI GLboolean GLEWAPIENTRY wglewGetExtension (const char *name);
