//! author: BenjaminHampe@gmx.de
#pragma once

#ifndef DE_FORCE_INLINE
#define DE_FORCE_INLINE inline __attribute__((__always_inline__))
#endif
